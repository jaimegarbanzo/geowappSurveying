
__author__ = 'Jaime'

import vertical_accuracy_funct
import kmlparser
import sys
import numpy as np
import time
import os
start_time = time.time()

sample_path=sys.argv[1]#'C:\\ms4w\\Apache\\htdocs\\GEOWAPP\\uploads\\vertical_samples\\sampletest1.txt'
exercise_path=sys.argv[2]#'C:/ms4w/Apache/htdocs/GEOWAPP/uploads/vertical_check/test3.csv'

####### the following 2 variables are very important in the processing
###### the fist variable (accuracy_limit) indicates how much difference between the Z sample value and the Z interpolated value
### the second parameter (closest_points) indicates how many points will be used for interpolating the value
### the minimum value for closest_points is 3
accuracy_limit = float(sys.argv[3])
closest_points = int(sys.argv[4])

############### reading the sample content##########################
sample_content = open(sample_path, 'r').read()
sample_matrix= vertical_accuracy_funct.txtcsv_parser(sample_content)
del sample_content

############### reading the uploaded content##########################
exercise_content= open(exercise_path, 'r').read()
exercise_matrix=vertical_accuracy_funct.txtcsv_parser(exercise_content)
del exercise_content


################ extracting the sample headers ####################
sample_headers=sample_matrix[0]
sample_headers=[i.lower() for i in sample_headers]# lowercasing the headers

##################extracting the uploaded content headers##################
exercise_headers=exercise_matrix[0]
exercise_headers=[i.lower() for i in exercise_headers]


##########################deleting headers from the matrices###################
sample_matrix=np.delete(sample_matrix, (0), axis=0)
exercise_matrix=np.delete(exercise_matrix,(0), axis=0)


# this function finds if the there is an empty list in the array
# if there is an empty list it will deleted
# clean_empty(matrix)
sample_matrix=vertical_accuracy_funct.clean_empty(sample_matrix)
exercise_matrix=vertical_accuracy_funct.clean_empty(exercise_matrix)

#######################converting the matrices in np arrays#################
sample_matrix=np.array(sample_matrix)
exercise_matrix=np.array(exercise_matrix)

sample_matrix=vertical_accuracy_funct.make_float(sample_matrix)
exercise_matrix=vertical_accuracy_funct.make_float(exercise_matrix)

#get vector isolates the vector you want
sample_vector_x=vertical_accuracy_funct.get_vector(sample_matrix,sample_headers,'x')
sample_vector_y=vertical_accuracy_funct.get_vector(sample_matrix,sample_headers,'y')
sample_vector_z=vertical_accuracy_funct.get_vector(sample_matrix,sample_headers,'z')
sample_vector_id=vertical_accuracy_funct.get_vector(sample_matrix,sample_headers,'id')#change this function

exercise_vector_x=vertical_accuracy_funct.get_vector(exercise_matrix,exercise_headers,'x')
exercise_vector_y=vertical_accuracy_funct.get_vector(exercise_matrix,exercise_headers,'y')
exercise_vector_z=vertical_accuracy_funct.get_vector(exercise_matrix,exercise_headers,'z')
exercise_vector_id=vertical_accuracy_funct.get_vector(exercise_matrix,exercise_headers,'id')

del sample_matrix
del exercise_matrix

# define the closest points of the surronding samples

closest_distances=np.zeros(closest_points)
z_of_closest_points=np.zeros(closest_points)


dictionary=[[0 for x in range(closest_points+1)] for x in range(len(sample_vector_id))]# accessing the points
counter=0
Z_interpolated=np.zeros(len(sample_vector_id))
for i in range(len(sample_vector_id)):
    dictionary[i][0]=sample_vector_id[i]
    for k in range(len(exercise_vector_id)):
        distance=np.sqrt((sample_vector_x[i]-exercise_vector_x[k])**2+(sample_vector_y[i]-exercise_vector_y[k])**2)
        counter +=1
        if k<closest_points:# take the first 5 values an store them in a array
            closest_distances[k]=distance
            dictionary[i][k+1]=k
        else: # test the 5 values in order to know if it is less than a value that is already stored

            closest_distances, index=vertical_accuracy_funct.replace_the_biggest(closest_distances,distance)
            if index is not None:
                dictionary[i][index+1]=k# K is the index for accessing the different values
    for j in range(closest_points):
        z_of_closest_points[j]=exercise_vector_z[dictionary[i][j+1]]

    Z_interpolated[i]=vertical_accuracy_funct.IDW(z_of_closest_points,closest_distances)


z_indicator=np.subtract(sample_vector_z,Z_interpolated)    #z accuracy indicator
z_indicator=np.absolute(z_indicator)

z_indicator_squared = np.zeros(len(z_indicator))

z_indicator_squared = [i**2 for i in z_indicator]
standard_dev = np.sqrt(np.sum(z_indicator_squared)/(len(z_indicator)-1))

angles_array=[[0 for x in range(closest_points)] for x in range(len(sample_vector_id))]

################ this one compute the angles that will be use for ordering the points##############
for i in range(len(sample_vector_id)):
    for j in range(closest_points):
        angles_array[i][j]=np.arctan2(exercise_vector_y[dictionary[i][j+1]]-sample_vector_y[i],exercise_vector_x[dictionary[i][j+1]]-sample_vector_x[i])
        if angles_array[i][j]<0:
            angles_array[i][j]=angles_array[i][j]+2*(np.pi)


ordered_dic=[0 for i in range(len(dictionary))]
## this will order the dictionary by angle so when the KML is drawn there will be no crossing lines
for i in range(len(dictionary)):
    ordered_dic[i]=vertical_accuracy_funct.order_dict(angles_array[i],dictionary[i])

z_ind_color=["x" for i in range(len(z_indicator))]

for i in range(len(z_indicator)):
    if z_indicator[i]> accuracy_limit:
        z_ind_color[i]="red"
    else:
        z_ind_color[i]="green"

### coordinate transformation from NB stereo to latlong

long_elip_array,lat_elip_array=vertical_accuracy_funct.from_NBstereo_to_LatLon(sample_vector_x,sample_vector_y)

exercise_long,exercise_lat=vertical_accuracy_funct.from_NBstereo_to_LatLon(exercise_vector_x,exercise_vector_y)

z_indicator=z_indicator.tolist()


########################### parsing a KML file########################################
acuracypolygons=kmlparser.KMLparser(ordered_dic,exercise_long,exercise_lat,z_ind_color,exercise_vector_id)

###########################returning report############################################
report=vertical_accuracy_funct.reporting(ordered_dic,sample_vector_z,Z_interpolated,exercise_vector_id,standard_dev)

#######################Saving Files####################################

######################writing reports###############################
folder_path='../KMLS'
folder_path=os.path.realpath(folder_path)
KML_name="/KML_"
file=vertical_accuracy_funct.filewriter(folder_path,KML_name,".kml",acuracypolygons)
KML_name=os.path.basename(file)

###################### WRITING REPORT###############################
folder_path='../REPORTS'
folder_path=os.path.realpath(folder_path)
report_name='/vertical_accuracy'
file=vertical_accuracy_funct.filewriter(folder_path,report_name,".txt",report)
report_name=os.path.basename(file)

procesing_time=time.time()-start_time

print(KML_name,report_name,procesing_time, sep='::')