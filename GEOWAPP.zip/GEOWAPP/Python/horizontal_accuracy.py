__author__ = 'Jaime'

import vertical_accuracy_funct
import horizontal_accuracy_func
import mysql.connector
from mysql.connector import errorcode
import kmlparser
import sys
import numpy as np
import time
import os
start_time = time.time()

#sample_path = "C:/ms4w/Apache/htdocs/GEOWAPP/uploads/horizontal_samples/samples_prox_1.csv"#

#exercise_path = "C:/ms4w/Apache/htdocs/GEOWAPP/uploads/horizontal_check/points_prox_1.csv"#


#sample_path=sys.argv[1]#"C:/ms4w/Apache/htdocs/GEOWAPP/uploads/horizontal_samples/samples_prox_1.csv"#

##exercise_path=sys.argv[2]#"C:/ms4w/Apache/htdocs/GEOWAPP/uploads/horizontal_check/points_prox_1.csv"#



############### reading the sample content##########################
sample_content = open(sample_path, 'r').read()
sample_matrix= vertical_accuracy_funct.txtcsv_parser(sample_content)
del sample_content


############### reading the uploaded content##########################
exercise_content= open(exercise_path, 'r').read()
exercise_matrix=vertical_accuracy_funct.txtcsv_parser(exercise_content)
del exercise_content


################ extracting the sample headers ####################
sample_headers=sample_matrix[0]
sample_headers=[i.lower() for i in sample_headers]# lowercasing the headers


##################extracting the uploaded content headers##################
exercise_headers=exercise_matrix[0]
exercise_headers=[i.lower() for i in exercise_headers]


##########################deleting headers from the matrices###################
sample_matrix=np.delete(sample_matrix, (0), axis=0)
exercise_matrix=np.delete(exercise_matrix,(0), axis=0)


# this function finds if the there is an empty list in the array
# if there is an empty list it will deleted
# clean_empty(matrix)
sample_matrix=vertical_accuracy_funct.clean_empty(sample_matrix)
exercise_matrix=vertical_accuracy_funct.clean_empty(exercise_matrix)


# #get vector isolates the vector you want
###sample vector
sample_vector_x=np.array(vertical_accuracy_funct.get_vector(sample_matrix,sample_headers,'x'))
sample_vector_y=np.array(vertical_accuracy_funct.get_vector(sample_matrix,sample_headers,'y'))
sample_code_vector=horizontal_accuracy_func.get_code(sample_matrix,sample_headers,'code')
sample_id_vector=horizontal_accuracy_func.get_code(sample_matrix,sample_headers,'id')

### exercise vectors
exercise_vector_x=np.array(vertical_accuracy_funct.get_vector(exercise_matrix,exercise_headers,'x'))
exercise_vector_y=np.array(vertical_accuracy_funct.get_vector(exercise_matrix,exercise_headers,'y'))
exercise_code_vector=horizontal_accuracy_func.get_code(exercise_matrix,exercise_headers,'code')
exercise_id_vector=horizontal_accuracy_func.get_code(exercise_matrix,exercise_headers,'id')


cnx = mysql.connector.connect(user='freeuser', password='fre123', host='localhost:3306', database='geowapp')
cursor = cnx.cursor()

query = "SELECT id, code, type, tolerance  FROM feature_tolerance"

cursor.execute(query)
tolerance_matix=cursor.fetchall()

cnx.close()

tolerance_header=("id", "code","type", "tolerance")

tolerance_id=horizontal_accuracy_func.get_code(tolerance_matix,tolerance_header,'id')
tolerance_code=horizontal_accuracy_func.get_code(tolerance_matix,tolerance_header,'code')
tolerance_type=horizontal_accuracy_func.get_code(tolerance_matix,tolerance_header,'type')
tolerance_tolerance=vertical_accuracy_funct.get_vector(tolerance_matix,tolerance_header,'tolerance')


counter=0
sample_processed=[]
sample_processed_id=[]
exercise_id_processed=[]
distance_from_sample=[]
for code in tolerance_code:
        str(code)
        sample_list = []
        for i in range(len(sample_code_vector)):
            if code == sample_code_vector[i]:
                sample_list.append(i)
        exercise_list = []
        for i in range(len(exercise_code_vector)):
            if code == exercise_code_vector[i]:
                exercise_list.append(i)
        if len(sample_list) != 0:
            for sample in sample_list:
                checker = 0
                for point in exercise_list:
                    distance = np.sqrt((sample_vector_x[sample]-exercise_vector_x[point])**2+(sample_vector_y[sample]-exercise_vector_y[point])**2)
                    if distance < tolerance_tolerance[counter]:
                        sample_processed.append("green")
                        sample_processed_id.append(sample)
                        checker = 1
                        exercise_id_processed.append(exercise_id_vector[point])
                        distance_from_sample.append(distance)
                    elif point == exercise_list[-1] and checker == 0:
                        sample_processed.append("red")
                        sample_processed_id.append(sample)
        counter += 1

#converting the sample and exercice matrix in vector in WGS 84
long_elip_sample,lat_elip_sample=vertical_accuracy_funct.from_NBstereo_to_LatLon(sample_vector_x,sample_vector_y)

long_elip_exercise,lat_elip_exercise=vertical_accuracy_funct.from_NBstereo_to_LatLon(exercise_vector_x,exercise_vector_y)

rounded_distance=[]
for i in distance_from_sample:
        rounded_distance.append(str(round(i,3)))


# Processing the KML
proximity_points = kmlparser.KMLparser_prox(rounded_distance,exercise_vector_x,long_elip_exercise,lat_elip_exercise,sample_processed_id,sample_processed,sample_id_vector,exercise_id_processed,long_elip_sample,lat_elip_sample)

# making the Report
report = horizontal_accuracy_func.reporting(sample_processed,sample_id_vector,sample_processed_id,exercise_id_processed,rounded_distance)

print(report)
######################writing reports###############################
folder_path=os.path.abspath(os.path.join(os.path.dirname(__file__),"../KMLS"))
KML_name="/KML_"
file=vertical_accuracy_funct.filewriter(folder_path,KML_name,".kml",proximity_points)
KML_name=os.path.basename(file)


###################### WRITING REPORT###############################
folder_path=os.path.abspath(os.path.join(os.path.dirname(__file__),"../REPORTS"))
report_name='/proximity_eva_'
file=vertical_accuracy_funct.filewriter(folder_path,report_name,".txt",report)
report_name=os.path.basename(file)
procesing_time=time.time()-start_time

print(KML_name,report_name,procesing_time,sep='::')