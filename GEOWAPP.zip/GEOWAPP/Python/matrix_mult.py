import sys
import json
import mat_par
import numpy as np
from scipy import linalg
# getting the variable from php
#test=[['1.0',    '0.0',   '98.5'], ['0.0',   '-1.0',    '5.5'], ['1.0',   '1.0',    '1.0']]

# this part load the json string send it to mparser
# and convert it into a np array

coef_matrix=np.array(mat_par.parsemat(sys.argv[1]))
#converts the string array into a float type array
coef_matrix=coef_matrix.astype(np.float)

coef_matrix_tp=np.transpose(coef_matrix)

weight_matrix=np.array(mat_par.parsemat(sys.argv[2]))
#convert the string array into a np float array
weight_matrix=weight_matrix.astype(np.float)

l_vector=np.array(mat_par.parsevec(sys.argv[3]))
##convert the string array into a np float array
l_vector=l_vector.astype(np.float)

deg_free=float(sys.argv[4])# deg_free


### the least squares begins
# calculating N= (tranp(A))W A where A is the coeficiente matrix and W the weight matrix
weigts_dot_A=np.dot(weight_matrix,coef_matrix)

N=np.dot(coef_matrix_tp,weigts_dot_A)
# computing inv N
N_inv=linalg.inv(N)

# computing AT*W*L
AT_dot_weights=np.dot(coef_matrix_tp,weight_matrix)

AT_W_L=np.dot(AT_dot_weights,l_vector)

#computin X vector
X_vector=np.dot(N_inv,AT_W_L)

#computing the residual

residuals=np.subtract(np.dot(coef_matrix,X_vector),l_vector)

#computing standart deviation

S_dev =np.sqrt(np.dot(np.transpose(residuals),np.dot(weight_matrix,residuals))/deg_free)
diagonal_inv=np.diagonal(N_inv)
S_dev_diag=[np.sqrt(i)*S_dev for i in diagonal_inv]

#Converting the result into string
X_vector_string=np.array2string(X_vector, separator=',').replace("]", '').replace('[', '')

residuals_str=np.array2string(residuals, separator=',').replace("]", '').replace('[', '')

S_dev_str=np.array2string(np.array(S_dev_diag),separator=',').replace("]", '').replace('[', '')

#

## Sending the results
print(X_vector_string, S_dev_str, residuals_str, sep='::')


