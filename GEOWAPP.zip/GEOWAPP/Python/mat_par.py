# parsemat takes a json string and converted into
# a multidimentional list
# the output is a list of string
# Ex. input {1:{1:1,1:2}, 2:{1:3,2:2.3}}
#     output [[1, 2],[3,2.3]]
# this function was developed by Titus Tienaah

def parsemat(json_matstr):
    json_matstr=json_matstr.split('},')
    json_matstr=[i.replace('{', '').replace('}', '') for i in json_matstr]
    json_matstr=[i.replace(',', '/').replace(':', '/') for i in json_matstr]
    json_matstr=[i.split('/') for i in json_matstr]
    json_matstr=[i[1:] for i in json_matstr]
    json_matstr=[i[1::2] for i in json_matstr]
    return json_matstr

def parsevec(json_vector):
    json_vector=json_vector.split(',')
    json_vector=[i.replace('{', '').replace('}', '') for i in json_vector]
    json_vector=[i.split(':') for i in json_vector]
    json_vector=[i[1::2] for i in json_vector]
    return json_vector

