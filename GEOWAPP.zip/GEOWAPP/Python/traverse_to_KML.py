__author__ = 'Jaime'

import sys
import kmlparser
import numpy as np
import mat_par
import vertical_accuracy_funct
import mysql.connector
import os


### this data that is showed as comments is for testing and debuging the application
###
# A="{ 1 : 7438030.147861404 , 2 :7438068.4167787, 3 :7437997.5450849, 4 :7438249.4229738, 5 :7438113.2595805, 6 :7438348.3237927, 7 :7438322.2246514}"
# B="{ 1 : 2489045.2799748294 , 2 :2489118.9525229, 3 :2489258.8600158, 4 :2489020.9691571, 5 :2489365.1711249, 6 :2489186.0659613, 7 :2489368.9015747}"
# C="{ 1 : 7438030.147861404 , 2 :7438068.4103931, 3 :7437997.5266362, 4 :7438249.3778767, 5 :7438113.1860122, 6 :7438348.2274938, 7 :7438322.1141469}"
# D="{ 1 : 2489045.2799748294 , 2 :2489118.9559826, 3 :2489258.8700116, 4 :2489020.9935915, 5 :2489365.2109854, 6 :2489186.1181376, 7 :2489368.9614478}"
# F='tst1'
# G='tst2'

A = sys.argv[1]#"{ 1 : 7438030.147861404 , 2 :7438068.4167787, 3 :7437997.5450849, 4 :7438249.4229738, 5 :7438113.2595805, 6 :7438348.3237927, 7 :7438322.2246514}"
B = sys.argv[2]#"{ 1 : 2489045.2799748294 , 2 :2489118.9525229, 3 :2489258.8600158, 4 :2489020.9691571, 5 :2489365.1711249, 6 :2489186.0659613, 7 :2489368.9015747}"
C = sys.argv[3]#"{ 1 : 7438030.147861404 , 2 :7438068.4103931, 3 :7437997.5266362, 4 :7438249.3778767, 5 :7438113.1860122, 6 :7438348.2274938, 7 :7438322.1141469}"
D = sys.argv[4]#"{ 1 : 2489045.2799748294 , 2 :2489118.9559826, 3 :2489258.8700116, 4 :2489020.9935915, 5 :2489365.2109854, 6 :2489186.1181376, 7 :2489368.9614478}"
F = sys.argv[5]#'tst1'
G = sys.argv[6]#'tst2'


lat_not_cor=np.array(mat_par.parsevec(A)).astype(np.float)#sys.argv[1])
lon_not_cor=np.array(mat_par.parsevec(B)).astype(np.float)#sys.argv[2])

lat_cor=np.array(mat_par.parsevec(C)).astype(np.float)#sys.argv[3])
lon_cor=np.array(mat_par.parsevec(D)).astype(np.float)#sys.argv[4])

station1=F
station2=G

cnx = mysql.connector.connect(user='freeuser', password='fre123', host='localhost', database='geowapp')
cursor = cnx.cursor()

query = 'SELECT x,y FROM stations where code="'+station1+'"'
cursor.execute(query)
station1_data=cursor.fetchall()

query = 'SELECT x,y  FROM stations where code="'+station2+'"'

cursor.execute(query)

station2_data=cursor.fetchall()

cnx.close()

X_stations=[]

X_stations.append(station1_data[0][0])
X_stations.append(station2_data[0][0])

Y_stations=[]

Y_stations.append(station1_data[0][1])
Y_stations.append(station2_data[0][1])


elip_long_station,elip_lat_station=vertical_accuracy_funct.from_NBstereo_to_LatLon(X_stations,Y_stations)


elip_long_not_correct, elip_lat_not_correct=vertical_accuracy_funct.from_NBstereo_to_LatLon(lon_not_cor,lat_not_cor)

elip_long, elip_lat=vertical_accuracy_funct.from_NBstereo_to_LatLon(lon_cor,lat_cor)

traverse_non_adjusted,traverse_adjusted=kmlparser.kml_traverse(elip_long_not_correct, elip_lat_not_correct,elip_long, elip_lat,elip_long_station,elip_lat_station,station1,station2)

# writing the kmls
folder_path=os.path.abspath(os.path.join(os.path.dirname(__file__),"../KMLS"))
KML_name="/KML_non_adjusted"
file=vertical_accuracy_funct.filewriter(folder_path,KML_name,".kml",traverse_non_adjusted)
KML_name_non_adjusted=os.path.basename(file)

folder_path=os.path.abspath(os.path.join(os.path.dirname(__file__),"../KMLS"))
KML_name="/KML_adjusted"
file=vertical_accuracy_funct.filewriter(folder_path,KML_name,".kml",traverse_adjusted)
KML_name_adjusted=os.path.basename(file)

print(KML_name_non_adjusted,KML_name_adjusted,sep="::")