__author__ = 'Jaime'

import numpy as np
import time

dictionary=[([ 1.,  2.,  3.,  8.,  5.,  4.]), ([ 2.,  3.,  8.,  9.,  5.,  4.]), ([ 3.,  4.,  2.,  5.,  0.,  6.]), ([ 4.,  0.,  4.,  5.,  9.,  1.]), ([ 5.,  7.,  2.,  4.,  0.,  6.])]
Z_real=[ 100.,  120.,  105.,   95.,   99.]
Z_interpolated=[ 101.68997014,  100.9735795,   103.52234391,  108.14854472,   98.68343877]
exercise_vector_id=[ 10. ,  9.,   8. ,  7. ,  6. ,  5. ,  4.,   3. ,  2.,   1.]
exercise_vector_id=[int(x) for x in exercise_vector_id]

report="#sample\t"
dictionary=[[int(x) for x in y] for y in dictionary]

for i in range(len(dictionary[0])-1):
    report=report+'PT'+str(i+1)+'\t'

report=report+'Z(real)\t'+'Z(inter)\n'

for i in range(len(dictionary)):
    for j in range(len(dictionary[0])+1):
        if j==0:
             report=report+str(dictionary[i][j])+"\t"
        elif j<=(len(dictionary[0])-1):
            report=report+str(exercise_vector_id[dictionary[i][j]])+"\t"
        else:
            report=report+str(Z_real[i])+"\t"+str(Z_interpolated[i])
    report=report+'\n'


index_collum=len(dictionary[0])+1
index_row=len(dictionary)+1

print(report)
