__author__ = 'Jaime'

### kml parser made in order to create KML polygons

def KMLparser(dictionary,lon_elip,lat_elip,color,exercise_vector_id):

    dictionary=[[int(x) for x in y] for y in dictionary]
    lon_elip=[str(x) for x in lon_elip]
    lat_elip=[str(x) for x in lat_elip]

    # defining styles '
    badpoly='<Style id="badpoly"> <LineStyle><width>4</width></LineStyle>' \
            '<PolyStyle><color>231400FA</color></PolyStyle></Style>'
    goodpoly='<Style id="goodpoly"> <LineStyle><width>4</width></LineStyle>' \
             '<PolyStyle><color>5a00FA14</color></PolyStyle></Style>'

    # KML begin forming
    KML='<?xml version="1.0" encoding="UTF-8"?><kml xmlns="http://www.opengis.net/kml/2.2">'

    KML=KML+'<Document><name>results</name>'

    KML=KML+badpoly+goodpoly

    index=len(dictionary[0])-1

    for i in range(len(dictionary)):
        placemarks='<Placemark><name>'+str(dictionary[i][0])+'</name>'

        if(color[i]=="red"):
            placemarks=placemarks+'<styleUrl>#badpoly</styleUrl>'
        elif(color[i]=="green"):
            placemarks=placemarks+'<styleUrl>#goodpoly</styleUrl>'

        placemarks=placemarks+'<Polygon><extrude>1</extrude><altitudeMode>relativeToGround</altitudeMode><outerBoundaryIs>'
        coordinates=''
        for j in range(index):
            if j==0:
                fist_coord=lon_elip[dictionary[i][j+1]]+','+lat_elip[dictionary[i][j+1]]+',0'
            coordinates=coordinates+lon_elip[dictionary[i][j+1]]+','+lat_elip[dictionary[i][j+1]]+',0'+' '
        coordinates=coordinates+fist_coord
        coordinates='<coordinates>'+coordinates+'</coordinates>'

        placemarks=placemarks+'<LinearRing>'+coordinates+'</LinearRing>'
        placemarks=placemarks+'</outerBoundaryIs></Polygon></Placemark>'
        KML=KML+placemarks

    for i in range(len(exercise_vector_id)):
        KML=KML+'<Placemark><name>'+str(exercise_vector_id[i])+'</name>'
        KML=KML+'<Point><coordinates>'+lon_elip[i]+','+lat_elip[i]+',0'+'</coordinates></Point></Placemark>'


    KML=KML+'</Document></kml>'

    return (KML)
def KMLparser_prox(rounded_distance,exercise_vector_x,long_elip_exercise,lat_elip_exercise,sample_proccesed_id,sample_proccesed,sample_id_vector,exercise_id_processed,long_elip_sample,lat_elip_sample):
    KML = '<?xml version="1.0" encoding="UTF-8"?><kml xmlns="http://www.opengis.net/kml/2.2">'
    KML = KML+'<Document><name>horizontal acurracy</name>'
    exercise_KML_style = '<Style id="exercise"><IconStyle><Icon>' \
                       '<href>http://maps.google.com/mapfiles/kml/pushpin/ylw-pushpin.png</href>' \
                       '</Icon></IconStyle></Style>'
    InTolerance_style = '<Style id="InTolerance"><IconStyle><Icon>' \
                       '<href>http://maps.google.com/mapfiles/kml/paddle/grn-stars.png</href>' \
                       '</Icon></IconStyle></Style>'
    OffTolerance_style='<Style id="OffTolerance"><IconStyle><Icon>' \
                       '<href>hhttp://maps.google.com/mapfiles/kml/paddle/X.png</href>' \
                       '</Icon></IconStyle></Style>'
    KML=KML+exercise_KML_style+InTolerance_style+OffTolerance_style




    for i in range(len(exercise_vector_x)):
        if i==0:
            KML=KML+"<Folder><name>Surveyed Points</name>"
        KML=KML+"<Placemark><name>"+str(i)+"</name> <styleUrl>#exercise</styleUrl><Point><coordinates>"
        KML=KML+str(long_elip_exercise[i])+","+str(lat_elip_exercise[i])+","+"0"+"</coordinates></Point></Placemark>"
    KML=KML+"</Folder>"

    counter=0
    for i in range(len(sample_proccesed_id)):
        if i==0:
            KML=KML+"<Folder><name>Results</name>"
        if sample_proccesed[i] == "green":
            style="#InTolerance"
            description='S: '+str(sample_id_vector[sample_proccesed_id[i]])+" - "+str(exercise_id_processed[counter])+" D:= "+ rounded_distance[counter]
            counter +=1
        elif sample_proccesed[i] == "red":
            style="#OffTolerance"
            description='Samp '+str(sample_id_vector[sample_proccesed_id[i]])+" to Nd"
        KML=KML+"<Placemark><name>"+description+"</name> <styleUrl>"+style+"</styleUrl><Point><coordinates>"
        KML=KML+str(long_elip_sample[sample_proccesed_id[i]])+","+str(lat_elip_sample[sample_proccesed_id[i]])+","+"0"+"</coordinates></Point></Placemark>"
    KML = KML+"</Folder></Document></kml>"
    return KML

def  kml_traverse(elip_long_not_correct, elip_lat_not_correct,elip_long, elip_lat,elip_long_station,elip_lat_station,station1,station2):
    non_adjustedpoly='<Style id="non_adjusted"> <LineStyle><width>4</width><color>501400FF</color></LineStyle></Style>'

    adjustedpoly='<Style id="adjusted"> <LineStyle><width>4</width><color>5000F014</color></LineStyle></Style>'

    # KML begin forming
    KML_1='<?xml version="1.0" encoding="UTF-8"?><kml xmlns="http://www.opengis.net/kml/2.2">'

    KML_1=KML_1+'<Document><name>traverse_poly</name>'

    KML_1=KML_1+non_adjustedpoly+adjustedpoly

    for i in range(len(elip_lat_not_correct)):
        if i==0:
            KML_1=KML_1+"<Placemark><name>non adjusted traverse</name> <styleUrl>#non_adjusted</styleUrl> <LineString><extrude>1</extrude>" \
                    "<altitudeMode>clampToGround </altitudeMode><coordinates>"
        KML_1=KML_1+str(elip_long_not_correct[i][0])+","+str(elip_lat_not_correct[i][0])+","+"0"+" "
    KML_1=KML_1+"</coordinates></LineString></Placemark></Document></kml>"

    KML_2='<?xml version="1.0" encoding="UTF-8"?><kml xmlns="http://www.opengis.net/kml/2.2">'

    KML_2=KML_2+'<Document><name>traverse_poly</name>'

    KML_2=KML_2+non_adjustedpoly+adjustedpoly
    for i in range(len(elip_lat_not_correct)):
        if i==0:
            KML_2=KML_2+"<Placemark><name>adjusted traverse</name> <styleUrl>#adjusted</styleUrl> <LineString><extrude>1</extrude>" \
                    "<altitudeMode>clampToGround </altitudeMode><coordinates>"
        KML_2=KML_2+str(elip_long[i][0])+","+str(elip_lat[i][0])+","+"0"+" "
    KML_2=KML_2+"</coordinates></LineString></Placemark>"


    KML_2=KML_2+"<Placemark><name>"+station1+"</name>"+"<Point><coordinates>"+str(elip_long_station[0])+","+str(elip_lat_station[0])+",0</coordinates></Point></Placemark>"
    KML_2=KML_2+"<Placemark><name>"+station2+"</name>"+"<Point><coordinates>"+str(elip_long_station[1])+","+str(elip_lat_station[1])+",0</coordinates></Point></Placemark>"

    KML_2=KML_2+"</Document></kml>"

    return(KML_1,KML_2)


