__author__ = 'Jaime'

# this funtion get the code vector
# however is useful when you need to find a vector of strings and separate them
def get_code(matrix, headers,vector):
    index=0
    for i in headers:
        if i== vector:
            code_colunm=index
        index +=1
    code_vector=[]
    for i in range(len(matrix)):
        code_vector.append(matrix[i][code_colunm])
    return code_vector

def reporting(sample_processed,sample_id_vector,sample_processed_id,exercise_id_processed,rounded_distance):


    report='#sample\tPoint\tdistance\t\n'

    counter=0
    for i in range(len(sample_processed)):

        if sample_processed[i] == "green":
            report=report+str(sample_id_vector[sample_processed_id[i]])+'\t'+str(exercise_id_processed[counter])+'\t'+ rounded_distance[counter]

            counter +=1
        elif sample_processed[i] == "red":
            report=report+str(sample_id_vector[sample_processed_id[i]])+"\tNd\tNd"

        report=report+'\n'

    return(report)
