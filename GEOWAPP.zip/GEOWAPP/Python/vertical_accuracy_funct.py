__author__ = 'Jaime'
import numpy as np

def txtcsv_parser(filestring):
    if ',' in filestring:
        delimeter=','
    elif ';' in filestring:
        delimeter=';'
    else:
        return "the file is not a comma or semicolon deilimeted"
    filestring=filestring.replace('\r', '')
    filestring=filestring.split('\n')

    filestring=[i.split(delimeter) for i in filestring]

    return filestring

def make_float(float_matrix):
    n=0
    for i in float_matrix:
        m=0
        for k in i:
            float_matrix[n][m]=float(k)
            m +=1
        n +=1
    return float_matrix
def clean_empty(matrix):
    j=0
    for i in matrix:
        for k in i:
            if not k:
                matrix=np.delete(matrix, j,axis=0)
        j += 1
    return matrix

def get_vector(matrix, headers, vector):
    index=0
    for i in headers:
        if i==vector:
            x_index=index
        index +=1
    index=0

    vector_x=np.zeros(len(matrix))

    for i in matrix:
        vector_x[index]=matrix[index][x_index]
        index +=1
    return vector_x

def replace_the_biggest(Array,subject):# this function looks into an array
    # and replaces the one which is greater in the array
    count1=0
    index= None
    for i in range(len(Array)):
        if subject<Array[i] and count1==0:
            diff1=Array[i]-subject
            count1 +=1
            index=i
        elif subject<Array[i] and count1 != 0:
            diff2=Array[i]-subject
            if diff2>diff1:
                diff1=diff2
                index=i
    if index is not None:
        Array[index]=subject
    return (Array, index)
def IDW(z_array,dist_array):
    sum_inv=0
    mult_z=0

    for i in range(len(dist_array)):
        inv_dist=1/dist_array[i]
        mult_z=mult_z+z_array[i]*inv_dist
        sum_inv=sum_inv+inv_dist

    Z=mult_z/sum_inv
    return Z
# def rearenging_dic(angle_array,dictionary):
#
#     for i in range(len(dictionary)):
#         checker=0
#         array=angle_array[i]
#         for j in range(len(angle_array[0])):# this will give us the number of collunms
#             if angle_array[i][checker]<angle_array[i][j] and j:
#                 checker +=1

def from_NBstereo_to_LatLon(array_x,array_y):
    deg_to_rad=(np.pi/180)
    rad_to_deg=(180/np.pi)
    X0=2500000# origing of the projection
    Y0=7500000# origing of the projection
    R=6379303.38# radius of the conformal sphere evaluated in Theta(0)
    K0=0.999912# scale factor
    a=6378137
    b=6356752.3141403561
    e2=(a**2-b**2)/(a**2) # e to the power of 2
    e=np.sqrt(e2)
    lat_0=46.5*deg_to_rad
    lon_0=-66.5*deg_to_rad

    N=a/((1-e2*(np.sin(lat_0)**2))**(1/2))
    M=a*(1-e2)/((1-e2*(np.sin(lat_0)**2))**(3/2))
    R=np.sqrt(N*M)

    required_precision=(0.00001/3600)*deg_to_rad

    c1=np.sqrt(1+(((e2)*((np.cos(lat_0))**4))/(1-e2)))
    lat_conf_0=np.arcsin(np.sin(lat_0)/c1)
    long_conf_0=c1*lon_0

    c2=np.tan(45*deg_to_rad+lat_conf_0/2)*(np.tan(45*deg_to_rad+lat_0/2)*((1-e*np.sin(lat_0))/(1+e*np.sin(lat_0)))**(e/2))**(-c1)


    lat_elip_array=[0 for i in range(len(array_x))]
    lon_elip_array=[0 for i in range(len(array_x))]
    S=[0 for i in range(len(array_x))]
    for i in range(len(array_x)):
        X_prime=(array_x[i]-X0)/K0
        Y_prime=(array_y[i]-Y0)/K0
        S= np.sqrt(X_prime**2+ Y_prime**2)
        cosb=X_prime/S
        sinb=Y_prime/S
        delta=2*np.arctan(S/(2*R))
        lat_conf=np.arcsin(np.sin(lat_conf_0)*np.cos(delta)+np.sin(delta)*np.cos(lat_conf_0)*sinb)
        residual=1
        lastvalue=lat_conf
        while(residual>required_precision):
            # creating the first function
            f1_elm_1=np.tan(45*deg_to_rad + lastvalue/2)
            f1_elm_2=((1-e*np.sin(lastvalue))/(1+e*np.sin(lastvalue)))**(e/2)
            f1_elm_3=np.tan(45*deg_to_rad+lat_conf/2)
            func_lat=c2*((f1_elm_1*f1_elm_2)**c1)-f1_elm_3
            # creating the second function
            f2_elm_1=f1_elm_1
            f2_elm_2=f1_elm_2
            f2_elm_3=0.5*((1/(np.cos(45*deg_to_rad+lastvalue/2)))**2)
            f2_elm_4=e2*np.cos(lastvalue)/(1-e2*((np.sin(lastvalue))**2))
            f2_elm_5=np.tan(45*deg_to_rad+lastvalue/2)
            func_lat_prime=c1*c2*((f2_elm_1*f2_elm_2)**(c1-1))*f2_elm_2*(f2_elm_3-f2_elm_4*f2_elm_5)
            lat_elip=lastvalue-func_lat/func_lat_prime
            residual=lat_elip-lastvalue
            lastvalue=lat_elip

        lat_elip_array[i]=lat_elip*rad_to_deg
        long_conf=long_conf_0+np.arcsin(np.sin(delta)*cosb/np.cos(lat_conf))
        lon_elip=long_conf/c1
        lon_elip_array[i]=lon_elip*rad_to_deg

    return(lon_elip_array,lat_elip_array)

def order_dict(anglearray,dictionary):
    import numpy as np
    sample_id=dictionary[0]
    dictionary=dictionary[1:len(dictionary)]
    array2=anglearray
    ordered_indeces=[0 for i in range(len(anglearray))]
    ordered_dict=[0 for i in range(len(anglearray))]
    for i in range(len(anglearray)):
        a=array2[0]
        switch=0
        for j in range(len(array2)):
            if a>array2[j]:
                a=array2[j]
                ordered_indeces[i]=j
                ordered_dict[i]=dictionary[j]
                switch=1
            elif j==(len(array2)-1) and switch==0:
                ordered_indeces[i]=0
                ordered_dict[i]=dictionary[0]
        array3=array2
        dictionary1=dictionary
        array2=[0 for i in range(len(array2)-1)]
        dictionary=[0 for i in range(len(dictionary)-1)]
        counter=0
        for j in range(len(array2)+1):
            if j!=ordered_indeces[i]:
                array2[counter]=array3[j]
                dictionary[counter]=dictionary1[j]
                counter +=1

    ordered_dict=np.append(sample_id,ordered_dict)

    return(ordered_dict)

def reporting(dictionary,Z_real,Z_interpolated,exercise_vector_id,standard_dev):
    exercise_vector_id=[int(x) for x in exercise_vector_id]

    report="#sample\t"
    dictionary=[[int(x) for x in y] for y in dictionary]

    for i in range(len(dictionary[0])-1):
        report=report+'PT'+str(i+1)+'\t'

    report=report+'Z(real)\t'+'Z(inter)\n'

    for i in range(len(dictionary)):
        for j in range(len(dictionary[0])+1):
            if j==0:
                 report=report+str(dictionary[i][j])+"\t"
            elif j<=(len(dictionary[0])-1):
                report=report+str(exercise_vector_id[dictionary[i][j]])+"\t"
            else:
                report=report+str(Z_real[i])+"\t"+str(Z_interpolated[i])
        report=report+'\n'

    report=report+'Overal standard deviation: '+str(standard_dev)+'\n'
    return(report)

def filewriter(folder_path,basename,extension,data):
    import os
    import random
    import sys
    append1=random.choice('abcdefgihkj')
    append2=random.randint(0,10000)
    file_name=basename+append1+str(append2)+extension
    full_name=folder_path+file_name
    fileexist=os.path.exists(full_name)

    safenumber=0
    while fileexist:
        append1=random.choice('abcdefgih')
        append2=random.randint(0,1000)
        file_name=file_name+append1+str(append2)+extension
        full_name=folder_path+file_name
        fileexist=os.path.exists(full_name)
        if safenumber>10:
            fileexist=False
            print('error: too many files in KML or Reports folder. please contact with the administrator')
            sys.exit(0)
        safenumber += 1

    file=open(full_name, 'w')
    file.write(data)
    file.close()

    return (full_name)