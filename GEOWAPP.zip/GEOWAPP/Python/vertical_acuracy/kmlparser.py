__author__ = 'Jaime'

### kml parser made in order to create KML polygons

def KMLparser(dictionary,lon_elip,lat_elip,color):

    dictionary=[[int(x) for x in y] for y in dictionary]
    lon_elip=[str(x) for x in lon_elip]
    lat_elip=[str(x) for x in lat_elip]

    # defining styles '
    badpoly='<Style id="badpoly"> <LineStyle><width>4</width></LineStyle>' \
            '<PolyStyle><color>231400FA</color></PolyStyle></Style>'
    goodpoly='<Style id="goodpoly"> <LineStyle><width>4</width></LineStyle>' \
             '<PolyStyle><color>5a00FA14</color></PolyStyle></Style>'

    # KML begin forming
    KML='<?xml version="1.0" encoding="UTF-8"?><kml xmlns="http://www.opengis.net/kml/2.2">'

    KML=KML+'<Document><name>results</name>'

    KML=KML+badpoly+goodpoly

    index=len(dictionary[0])-1

    for i in range(len(dictionary)):
        placemarks='<Placemark><name>'+str(dictionary[i][0])+'</name>'

        if(color[i]=="red"):
            placemarks=placemarks+'<styleUrl>#badpoly</styleUrl>'
        elif(color[i]=="green"):
            placemarks=placemarks+'<styleUrl>#goodpoly</styleUrl>'

        placemarks=placemarks+'<Polygon><extrude>1</extrude><altitudeMode>relativeToGround</altitudeMode><outerBoundaryIs>'
        coordinates=''
        for j in range(index):
            if j==0:
                fist_coord=lon_elip[dictionary[i][j+1]]+','+lat_elip[dictionary[i][j+1]]+',0'
            coordinates=coordinates+lon_elip[dictionary[i][j+1]]+','+lat_elip[dictionary[i][j+1]]+',0'+' '
        coordinates=coordinates+fist_coord
        coordinates='<coordinates>'+coordinates+'</coordinates>'

        placemarks=placemarks+'<LinearRing>'+coordinates+'</LinearRing>'
        placemarks=placemarks+'</outerBoundaryIs></Polygon></Placemark>'
        KML=KML+placemarks

    KML=KML+'</Document></kml>'

    return (KML)