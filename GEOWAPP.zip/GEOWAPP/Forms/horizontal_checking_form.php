<form id="form" method="POST" enctype="multipart/form-data">
    <p>horizontal accuracy checking. Please upload the file</p>
    <table>
        <tr>
        <td>File:</td><td><input type="file" name="file"/></td>
        </tr>
        <tr>
            <td>Sample name:</td> 
            <td>
                <input type="text" name="sample_name"/>
            </td>
        </tr>
        <tr>
            <td><input type="submit" value="submit"/><td>
        </tr>
    </table>
</form> 

<script>
    $("#form").submit(function(){

    var formData = new FormData($(this)[0]);

    $.ajax({
        url: "PHPS/horizontal_accuracy.php",
        type: 'POST',
        data: formData,
        async: false,
        success: function () {
            alert("the file was successfully uploaded")
        },
        cache: false,
        contentType: false,
        processData: false
    }).done(function( data ) {
                $("#FormDisplayer").html(data);
            });
    return false;
});
 
</script>