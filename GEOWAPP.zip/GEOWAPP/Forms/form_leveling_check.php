
<H2>leveling checking</h2>
        

<form id="form" method="get">

    <!-- look for the translation of points of change tp== turning points-->
    <h4>Define the number of stations forward run</h4><input name="number_tps_forw"type="text" value="#points"/>
    <h4>Define the number of stations return run</h4><input name="number_tps_back"type="text" value="#points"/>

    <br>
    <input type="button" value="Submit" onclick="posting_check()"/>

</form>

<script type="text/javascript">
    function posting_check(){
        var data=$("#form").serialize();
        $.get("PHPS/check_lev_form_creator.php",data)
            .done(function( data ) {
                $("#FormDisplayer").html(data);
            });
            
    }
</script>   