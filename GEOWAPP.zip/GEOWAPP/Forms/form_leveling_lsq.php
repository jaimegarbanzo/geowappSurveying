<h2>Least squares processing</h2>

<form id="form" method="get">		
    <h4>Define the number of observation Eqs. involved in the least squares</h4>
    <input name="number_point_lsq" type="text" value="#points"/>
    <h4>Define the number of known BenchMark</h4>
    <input name="number_bms" type="text" value="#BM"/>
    <br>
    <input type="button" value="Submit" onclick="posting_lsq()"/>
</form>


<script type="text/javascript">
    function posting_lsq(){
        var data=$("#form").serialize();
        //alert(data);
        $.get("PHPS/lsqLev_FormCreator.php",data)
            .done(function( data ) {
                $("#FormDisplayer").html(data);
            });
            
    }
</script> 