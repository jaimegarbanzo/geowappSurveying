<h2>Traverse Checking</h2>
<form id="form" method="get">
	<h3>Select the traverse type</h3>
		<select name="traverse_type">
			<option value="1">Starts in point A and Finishes in point B</option>
			<option value="2">Starts and finishes in point A</option>
		</select>
		<br>
                <h4>Define the number of observations</h4><input type="text" value="#points" name="number_points" required>
		<br>
		<input type="button" value="Submit" onclick="posting()"/>       
</form>


<script type="text/javascript">
    function posting(){
        var data=$("#form").serialize();
        $.get("PHPS/Traverse_form_PHP.php",data)
            .done(function( data ) {
                $("#FormDisplayer").html(data);
            });
            
    }
</script>