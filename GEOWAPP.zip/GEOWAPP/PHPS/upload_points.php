<?php

/* this php will upload files to a database in order to
 * use them as sample points for different areas
 */
$name=$_FILES["file"]['name'];
$temp_name=$_FILES["file"]['tmp_name'];
$size=$_FILES["file"]['size'];
$error=$_FILES['file']['error'];
$max_size=500000;

// strip the extension of the file
$extension=  strtolower(substr($name, strpos($name, ".")+1));



// save the files in the server

if (isset($name)){// check whether the variable has been set
    if(!empty($name)){// check wheter the variable is not null
        
        if($extension==="txt"||$extension==="csv" && $size<=$max_size){
            $location=  realpath('../uploads/vertical_samples/');// location where the file will be store

            if(move_uploaded_file($temp_name, $location."//".$name)){// the doble slashes if for one to escape //=/
                echo '<ul><li>File uploaded</li></ul>';
                
            }
            else{
                echo '<h3>Error uploadding the file <a href="../Forms/upload_vpoint.html">return</a></h3> <br>';
                if($error){
                    switch ($error){
                        case 1;
                            echo 'The uploaded file exceeds the max file directive(PHP)';
                            break;
                        case 2:
                            echo 'The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form';
                            break;
                        case 3:
                            echo 'The uploaded file was only partially uploaded';
                            break;
                        case 4:
                            echo 'No file was uploaded';
                            break;
                        case 6:
                            echo 'Missing a temporary folder. Introduced in PHP 4.3.10 and PHP 5.0.3';
                            break;

                        case 7:
                            echo 'Failed to write file to disk';
                            break;
                }
                }
            }
        } else{
            echo '<h3>Just txt and csv extensions are accepted <a href="../Forms/upload_vpoint.html">return</a></h3>';
            die();
        }
        
    }

    else {
         echo '<h3>Please choose a File <a href="../Forms/upload_vpoint.html">return</a></h3>';
         die();
    }
}
else{
    echo "<h3>Internal error variable (name) has not been set</h3>";
    die();
}

?>


