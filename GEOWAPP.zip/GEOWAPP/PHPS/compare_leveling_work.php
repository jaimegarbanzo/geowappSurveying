          
<?php 
	session_start();
        
	// number of station will be useful for some loops	
	$number_tps_forw=$_GET["number_tps_forw"];
	$number_tps_back=$_GET["number_tps_back"];	
	
        echo '<a id="data" style="display:none">'.'number_tps_forw='.$number_tps_forw.'&number_tps_back='.$number_tps_back.'</a>';
        
	//store the code of the bench mark 1
	$bench_mark1=trim($_GET["BM1"]);
	
	//store the code of the bench mark 2
	$bench_mark2=trim($_GET["BM2"]); 
	
	//store the array for the forward run
	$plus_forw_array=$_GET["plus_forw"];
	$minus_forw_array=$_GET["minus_forw"];
		
	// store the array for the return run
	$plus_back_array=$_GET["plus_back"];
	$minus_back_array=$_GET["minus_back"]; 	
	
	// store the distance for the forward run and the backward run. 
	$dist_forw_array=$_GET["dist_forw"];
	$dist_back_array=$_GET["dist_back"];
	
	//Getting the BM1+ and BM2- values[first and last value]
	$plus_forw_BM1=$_GET["plus_forw_BM1"];
	$minus_forw_BM2=$_GET["minus_forw_BM2"];
	
	// Getting the BM2+ and BM1- values [fist and last value of the returning run]
	$plus_back_BM2=$_GET["plus_back_BM2"];
	$minus_back_BM1=$_GET["minus_back_BM1"];
	
	///////////////////////////////////////////////////////	
	///////////// here the computations begin/////////////
	/////////////////////////////////////////////////////
        
        //////////////// conecting to the database////////////////////////////
		
         $connect=mysqli_connect("yourDataBase", "yourID", "yourPass","yourDataBase");
        
        if(mysqli_connect_errno()){
            
            die('Cound not connect'.mysql_error());
        }

        $query=mysqli_query($connect,"SELECT * FROM `yourDataBase`.`bench_mark` WHERE `code`='$bench_mark1'"); 
        $num_rows= mysqli_num_rows($query);
   
        if(!$num_rows){
            die('This benchmark'." ($bench_mark1) "."have not been inserted in the database");
             }
        while ($rows = mysqli_fetch_array($query)) {
            $BM1_elev=$rows['z'];
            $BM_code=$rows['code'];
        }
        mysqli_close($connect);
        
        /////////////////// end of database connection/////////////////////////////////////
	//defining the elevation of the points
	//$BM1_elev=2053.18;// this is going to be replace for a data base value
	$ELEV_forw[1]=$BM1_elev;
	$counter1=1;
	$last_index=$number_tps_forw+1;
	
	/// this for computes the foward run 	
	for($i=1; $i<=$last_index; $i++) {
		
		 if($i==1) {
			$HI=$ELEV_forw[$i]+$plus_forw_BM1;
			$HI_forw[1]=$HI;
			$i++;	
		}
	 			 	  
	  $ELEV_forw[$i]=$HI_forw[$counter1]-$minus_forw_array[$counter1];
	  
	  $HI_forw[$i]=$ELEV_forw[$i]+$plus_forw_array[$counter1];
		
	 if($i==$last_index) {
			$ELEV_forw[($i+1)]=$HI_forw[$i]-$minus_forw_BM2;			  	
	  	}
	
	  $counter1++;
	}
	// this for computes the return run
	$BM2_elevation=$ELEV_forw[($last_index+1)];// store the last elevation 
	$ELEV_back[1]=$BM2_elevation;
	$counter1=1;
	$last_index=$number_tps_back+1;
	
	for($i=1; $i<=$last_index; $i++) {
		
		 if($i==1) {
			$HI=$ELEV_back[$i]+$plus_back_BM2;
			$HI_back[1]=$HI;
			$i++;	
		}
	 
         
	  $ELEV_back[$i]=$HI_back[$counter1]-$minus_back_array[$counter1];
	  
	  $HI_back[$i]=$ELEV_back[$i]+$plus_back_array[$counter1];
		
	 if($i==$last_index) {
			$ELEV_back[($i+1)]=$HI_back[$i]-$minus_back_BM1;// final ellevation; 			  	
	  	}
	
	  $counter1++;
	}
	
		$BM1_elev_return=$ELEV_back[($last_index+1)];
                
	 	// check the elevation clousure loop		 
		$check_1=round($BM1_elev_return-$BM1_elev, $precision = 4);	
		
		
		$Sum_plus=$plus_forw_BM1+array_sum($plus_forw_array)+$plus_back_BM2+array_sum($plus_back_array);
		$sum_minus=$minus_back_BM1+array_sum($minus_forw_array)+$minus_forw_BM2+array_sum($minus_back_array);		 
		
                // finds the misclousure error
                $check_2=round($Sum_plus-$sum_minus, $precision = 4);	 
		
	//computing the allowable loop "C"
		$total_dist=array_sum($dist_forw_array)+array_sum($dist_forw_array);	
		if (!$total_dist){
                	$total_dist=1;
                }
                $C=$check_2/sqrt($total_dist);	
        // this function checks whether the user is an Administrator or not. 
        $admin=$_SESSION['admin'];    
        
        //////////////////////////start connection with the database////////////////////////////
                
          $connect=mysqli_connect("yourDataBase", "yourID", "yourPass","yourDataBase");
        
        if(mysqli_connect_errno()){
            
            die('Cound not connect'.mysql_error());
        }

        $query=mysqli_query($connect,"SELECT * FROM `yourDataBase`.`leveling_precision_table` WHERE `c`>='$C' limit 1" ); 
        $num_rows= mysqli_num_rows($query);
   
        if(!$num_rows){
            die("connection lost with the database");
             }
        while ($rows = mysqli_fetch_array($query)) {
            $order=$rows['order'];
            $db_C=$rows['c'];
        }
        mysqli_close($connect);        
        //////////////////////////// database connection ends///////////////////////////////
        
        switch ($admin){
            case 0:
                echo '****************<br>';
                echo "<P>Misclosure: $check_1 m</p>";
                echo "<P>Distance: $total_dist km</p>";
                echo "<P>Precision Constant: $C m</p>";
                echo "<P>Order and Acurracy: $order</p>";
                echo "<p>database constant: $db_C</p>";
            break;
            case 1:
                echo '****************<br>';
                $counter1=1;
                $last_index=$number_tps_forw+1;
               for ($i=1; $i<=$last_index; $i++){
                
            
                        if($i==1) {

                             // this part the headers of the table are defined 
                             $report= '<table border="1px"><tr><th>Station</th><th>B.S. +(m)</th><th>HI</th><th>F.S. -(m)</th><th>Elevation(m)</th></tr>';
                             $report=$report."<tr><td>$bench_mark1</td><td>$plus_forw_BM1</td><td>--</td><td>--</td><td>$ELEV_forw[$i]</td></tr>";	
                             $report=$report. "<tr><td>--</td><td>--</td> <td>$HI_forw[$i]</td> <td>--</td><td>--</td></tr>";
                             
                        }    
                        else {
                            $report=$report. "<tr><td>TP $counter1</td><td>$plus_forw_array[$counter1]</td><td>--</td><td>$minus_forw_array[$counter1]</td><td>$ELEV_forw[$i]</td><tr>";
                            $report=$report. "<tr><td>--</td><td>--</td> <td>$HI_forw[$i]</td> <td>--</td><td>--</td></tr>";
                        
                        $counter1++;
                            if($i==$last_index){
                                $i++;
                                $report=$report."<tr><td>$bench_mark2</td><td>$plus_back_BM2</td><td>--</td><td>$minus_forw_BM2</td><td>$ELEV_forw[$i]</td></tr>";
                            }
                            
                        }
                     }
                     
                     $last_index=$number_tps_back;
                     $counter2=2;
                     for ($i=1; $i<=$last_index; $i++){
             
                             $report=$report. "<tr><td>--</td><td>--</td> <td>$HI_back[$i]</td> <td>--</td><td>--</td></tr>";
                             $report=$report. "<tr><td>TP $counter1</td><td>$plus_back_array[$i]</td><td>--</td><td>$minus_back_array[$i]</td><td>$ELEV_back[$counter2]</td><tr>";
                       
                        
                            if($i==$last_index){
                                $counter2++;
                                $report=$report."<tr><td>$bench_mark1</td><td>--</td><td>--</td><td>$minus_back_BM1</td><td>$ELEV_back[$counter2]</td></tr></table>";
                            }
                            
                        
                        $counter1++;
                        $counter2++;
                     }
                echo $report;                
                echo "<P>Misclosure: $check_1 m</p>";
                echo "<P>Distance: $total_dist km</p>";
                echo "<P>Precision Constant: $C m</p>";
                echo "<P>Order and Acurracy: $order</p>";
                echo "<p>database constant: $db_C</p>";
            break;
        }
?>