 <script type="text/javascript">
    function posting(){
        var data=$("#form").serialize();
        $.get("PHPS/bowditch.php",data)
            .done(function( data ) {
                $("#FormDisplayer").html(data)
            });

        }
 </script>

<?php
// this php function was created in order to create a form
// the form will as for acimut[degree, minutes, seconds] and distance 
//Variables 
	// this will dictate the number of lines that the form will ask for.
	// a line is composed by acimut[degree, minutes, seconds] and distance
	$traverse_type=$_GET["traverse_type"];
	$number_points=$_GET["number_points"];
	
	// these variables are used to create the form and another HTML tags
	$form_tag1='<form id="form" metod="get">';
	$form_tag2='</form>';
	// the tags are divided in 2 in order to assign a name if it were necesary to each field
	// then with the if you can assing a number to each name
	// this are the tags for degrees angle [deg, min, seg] [html]
	$input_tag1_deg='<input type="text" maxlength="3" name="';
	$input_tag2_deg='" size="8px"/>';
	$input_tag1_min='<input type="text" maxlength="2" name="';
	$input_tag2_min='" size="8px"/>';
	$input_tag1_seg='<input type="text" maxlength="2" name="';
	$input_tag2_seg='" size="8px"/>';
	
	// these are the tags for distance [html]
	$input_tag1_dist='<input type="text" name="';
	$input_tag2_dist='"/ size="16px">';
	// this variable manages the tags for a table [html]
	$table_tag1='<table>';
	$table_tag2='</table>';
	// this is the submit bottom stored in a variable
	$submit_buttom='<input type="button" value="submit" onclick="posting()">';
	 
	
  //Field validator 
	// validates if "number_points" is a integer
	
	if(is_numeric($number_points)) {
            echo "<h2> Please Insert the data </h2>";
            $number_dist_ang=$number_points;
		
            for($i=1; $i<=$number_dist_ang; $i++) {
			
                if($i== 1) {

                        // This part opens up the form

                        $traverse_form=$traverse_form.$form_tag1;

                        // this part the headers of the table are defined in order to create a form
                        //for recording the data of the traverse.
                        $traverse_form=$traverse_form.$table_tag1.'<tr>'.'<th>'.'Line'.'</th>';
                        $traverse_form=$traverse_form.'<th>'.'Degrees'.'</th>';
                        $traverse_form=$traverse_form.'<th>'.'Minutes'.'</th>';
                        $traverse_form=$traverse_form.'<th>'.'Seconds'.'</th>';
                        $traverse_form=$traverse_form.'<th>'.'Distance'.'</th>'.'</tr>';
                }
			
			  
                //this creates the input for degrees
                // tags are divided in two because it leave the posibility open to asign a name
                // For example
                //$input_tag1_dist."dist$i".$input_tag2_dist the result should be
                //<input type="text" name="dist1" size="8px"> for the i=1 in the loop

                // the name between tag creates directly a multidimentional array for degrees. 
                 $traverse_form=$traverse_form.'<tr>'.'<td>'."<h4>Line $i<h4>".'</td>';
                 $traverse_form=$traverse_form.'<td>'.$input_tag1_deg."ang[$i][deg]".$input_tag2_deg.'</td>';

                //this creates the input for minutes.
                 $traverse_form= $traverse_form.'<td>'.$input_tag1_min."ang[$i][min]".$input_tag2_min.'</td>';
                // this creates the input for seconds 
                $traverse_form= $traverse_form.'<td>'.$input_tag1_seg."ang[$i][seg]".$input_tag2_seg.'</td>';
                // this creates the input for distances
                $traverse_form=$traverse_form.'<td>'.$input_tag1_dist."dist[$i]".$input_tag2_dist.'</td>'.'</tr>';


             if($i== $number_dist_ang) {
                     // the following action will ask for a code of a point in order to retrive data from the 
                     // database. 

                     switch($traverse_type) {	
                             case "1":
                                             $traverse_form=$traverse_form.'<tr><td colspan="5"><h4>Insert the code of the control points</h4></td></tr>';
                                             $traverse_form=$traverse_form.'<tr><td><h4>Point A</h4><input type="text" name="coord[1]" size="10px"/><td>';
                                             $traverse_form=$traverse_form.'<td><h4>Point B</h4><input type="text" name="coord[2]" size="10px"/><td></tr>'; 
                             break;
                             case "2":
                                             $traverse_form=$traverse_form.'<tr><td colspan="5"><h4>Insert the code of the control point</h4></td></tr>';
                                             $traverse_form=$traverse_form.'<tr><td><h4>Point A</h4><input type="text" name="coord[1]" size="10px"/><td></tr>';
                             break;
                }			

                     // add the submit buttom 
                     $traverse_form=$traverse_form.'<tr>'.'<td>'.$submit_buttom.'</td>'.'</tr>';

                     // record the type of traverse in the form
                     $traverse_form=$traverse_form.'<tr>'.'<td>'.'<input type="hidden" name="traverse_type" value="';
                     $traverse_form=$traverse_form.$traverse_type.'"/>'.'</td>'.'</tr>';

                     // records the number of lines in the data 				
                     $traverse_form=$traverse_form.'<tr>'.'<td>'.'<input type="hidden" name="number_dist_ang" value="';

                     // closes the table				
                     $traverse_form=$traverse_form.$number_dist_ang.'"/>'.'</td>'.'</tr>'.$table_tag2;

                     // closes the form
                     $traverse_form=$traverse_form.$form_tag2;
                }
            }
		
	}
	else {
		echo '<h3 style="color:#ff0000;">Please type a number digit in Number of points<h3>';
                echo '<br>';
                echo '<a onclick="traversing1()"><h3>Return<h3></a>';
	} 
	// return the form to the main page
       
        $traverse_form=$traverse_form;
        
	echo "$traverse_form";
        echo "<br><br><br><br><br><br>"
?>			  			