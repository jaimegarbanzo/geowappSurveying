<?php
	session_start();
	
	session_destroy();
        
        echo "you are successfully logged out"."return to the <a href='../index.php'> main site</a>";

?>