<script type="text/javascript">
    function posting(){
        var data=$("#data").text();
        $.get("PHPS/Traverse_form_PHP.php",data)
            .done(function( data ) {
               $("#FormDisplayer").html(data);
         });
            
    }
</script>

<?php
session_start();

// get the number of points specified before
$number_dist_ang=$_GET["number_dist_ang"];

//This function records the angle multi-array.
// angle=(array [1](array ([deg]=> "deg",[min]=>"min",[seg]=>"seg"))}
$angle=$_GET["ang"];

// this function records the distance array 
// dist=aray([1]=>dist )  	
$dist=$_GET["dist"];
echo '<br>';
// this records  the code of a control point in order to make the query
$base_coor=$_GET["coord"];

// this records the traverse type; it can be one of 2 values
// it will tells which bowditch will be applied. 

$traverse_type=$_GET["traverse_type"];

// serialize the data if something goes wrong return to the previous form

$data='traverse_type='.$traverse_type.'&number_points='.$number_dist_ang;
echo '<a style="display:none" id="data">'.$data.'</a>';
if($traverse_type==="2"){
    $base_coor[2]=$base_coor[1];
}
        
/// this part validates the array

for($i=1; $i<=$number_dist_ang; $i++) {
    if(!is_numeric($angle[$i]["deg"])) {
        echo "<h3>The $i degree line is not numeric type</h3>"; 
        echo '<a onclick="posting()"><h3>Return</h3></a>';
        die();
        }
    if(!is_numeric($angle[$i]["min"])) {
             echo "<h3>The minutes line $i is not numeric type</h3>";
             echo '<a onclick="posting()"><h3>Return</h3></a>';
             die();
    }
    if(!is_numeric($angle[$i]["seg"])) {
             echo "<h3>The seconds line $i is not numeric type</h3>";
             echo '<a onclick="posting()"><h3>Return</h3></a>';
             die();
             
    }
    if(!is_numeric($dist[$i])) {
             echo "<h3>The $i distance line $i is not numeric type</h3>";
             echo '<a onclick="posting()"><h3>Return</h3></a>';
             die();
             
    }
}
        
              
////////////////////////////////////////////////////////
//////////////////database connection////////////////////

$connect=mysqli_connect("yourDataBase", "yourID", "yourPass","yourDataBase");

if(mysqli_connect_errno()){

    die('Cound not connect'.mysql_error());
}
        
        
        
$control_point1=trim($base_coor[1]);
$control_point2=trim($base_coor[2]);
$query=mysqli_query($connect,"SELECT * FROM `yourDataBase`.`stations` WHERE `code`='$control_point1'" );
$num_rows= mysqli_num_rows($query);
if(!$num_rows){
         die("connection lost with the database");
 }
while ($rows = mysqli_fetch_array($query)) {
   $A_lat=$rows['y'];
   $A_lon=$rows['x'];

   }
if($traverse_type=="1"){

       $control_point1=$base_coor[2];
       $query=mysqli_query($connect,"SELECT * FROM `yourDataBase`.`stations` WHERE `code`>='$control_point1'" ); 
       $num_rows= mysqli_num_rows($query);

       if(!$num_rows){
           die("connection lost with the database");
            }
       while ($rows = mysqli_fetch_array($query)) {
           $B_lat=$rows['y'];
           $B_lon=$rows['x'];

       }
}

   mysqli_close($connect);        

       //////////////////////////ends database connection////////////////////////////
       // 
	// This validates that all the values stored in the array are numeric


// this desides if is going to apply Bowditch or show an error message. 	
		
$residual_dep=0;
$residula_lat=0;

// this variable is the permited tolerance.
$tolerance=100;



for($i=1; $i<=$number_dist_ang; $i++) {
    // this function converts the [deg,min,seg] in rads
    $angle_rad[$i]=deg2rad($angle[$i]["deg"]+$angle[$i]["min"]/60+$angle[$i]["seg"]/3600); 

    // this function calculates the departures
    $departures[$i]=sin($angle_rad[$i])*$dist[$i];

    // this fucntion calculates the latitudes 
    $latitudes[$i]=cos($angle_rad[$i])*$dist[$i];
}


        // if this else is applied means that the traverse start in one point and ends in another
        //this is the same to say that $traverse_type==1;
        // then we applied a modified bowditch rule

switch ($traverse_type){	
    
    case 1:
         // here the coordinates of every point are computed however
        // there is not any applied ajustment 
        $lat_not_corrected[1]=$A_lat;
        $lon_not_corrected[1]=$A_lon;

        for($i=1; $i<=$number_dist_ang; $i++) {		
            $lat_not_corrected[$i+1]=$lat_not_corrected[$i]+$latitudes[$i]; 
            $lon_not_corrected[$i+1]=$lon_not_corrected[$i]+$departures[$i];
            $index_1=$i+1;

        }

        $residual_dep=-$B_lon+$lon_not_corrected[$index_1];
        $residual_lat=-$B_lat+$lat_not_corrected[$index_1];
        
       
        
        
        $sum_distances=array_sum($dist);	
        // if the linear misclosure is less than the tolerance then the traverse is adjusted.
        $linear_misclousure=sqrt(pow($residual_dep,2)+pow($residual_lat, 2));
        $traverse_tolerance=$linear_misclousure/$sum_distances;			
        $traverse_tolerance=round(pow($traverse_tolerance, -1),0);
       

        $proj_latitude[1]=$A_lat;
        $proj_longitude[1]=$A_lon;


        for($i=1; $i<=$number_dist_ang; $i++) {

            // Correction for departures
            $correction_dep[$i]=-($residual_dep*$dist[$i])/$sum_distances;	

            // Correction for longitude
            $correction_lat[$i]=-($residual_lat*$dist[$i])/$sum_distances;

            // applied coorrection the sum of $correc_departures and Correct Latitude should be 0.
            $correct_departures[$i]=$departures[$i]+$correction_dep[$i];
            $correct_latitudes[$i]=$latitudes[$i]+$correction_lat[$i]; 

            // computed the correct coordinates
            $proj_latitude[$i+1]=$proj_latitude[$i]+$correct_latitudes[$i];
            $proj_longitude[$i+1]=$proj_longitude[$i]+$correct_departures[$i];

        }
        break;
    case 2:
        // the residual are computed in the next section
        // this residuals should be close to 0 traverse type 2
        $lat_not_corrected[1]=$A_lat;
        $lon_not_corrected[1]=$A_lon;

        for($i=1; $i<=$number_dist_ang; $i++) {		
            $lat_not_corrected[$i+1]=$lat_not_corrected[$i]+$latitudes[$i]; 
            $lon_not_corrected[$i+1]=$lon_not_corrected[$i]+$departures[$i];
            $index_1=$i+1;

        }
        
        $residual_dep=array_sum($departures);
        $residual_lat=array_sum($latitudes);
        $sum_distances=array_sum($dist);
    

    // this compute the tolerance
    // if the linear misclosure is less than the tolerance then the traverse is adjusted.
        $linear_misclousure=sqrt(pow($residual_dep,2)+pow($residual_lat, 2));
        $traverse_tolerance=$linear_misclousure/$sum_distances;			
        $traverse_tolerance=round(pow($traverse_tolerance, -1),0);

    // if the traverse starts and finishes at at the same poit apply this
    // this is the same to say if $traverse_type==2


        $proj_latitude[1]=$A_lat;
        $proj_longitude[1]=$A_lon;

        for($i=1; $i<=$number_dist_ang; $i++) {

                // Correction for departures
                $correction_dep[$i]=-($residual_dep*$dist[$i])/$sum_distances;	

                // Correction for longitude
                $correction_lat[$i]=-($residual_lat*$dist[$i])/$sum_distances;

                // applied coorrection the sum of $correc_departures and Correct Latitude should be 0.
                $correct_departures[$i]=$departures[$i]+$correction_dep[$i];
                $correct_latitudes[$i]=$latitudes[$i]+$correction_lat[$i]; 

                // computed the correct coordinates
                $proj_latitude[$i+1]=$proj_latitude[$i]+$correct_latitudes[$i];
                $proj_longitude[$i+1]=$proj_longitude[$i]+$correct_departures[$i];

        }
        break;
}

// preparing data for passing to python
$lat_not_corr_json=  escapeshellarg(json_encode($lat_not_corrected, JSON_FORCE_OBJECT));
$lon_not_corr_json=  escapeshellarg(json_encode($lon_not_corrected, JSON_FORCE_OBJECT));

$proj_latitude_json=escapeshellarg(json_encode($proj_latitude, JSON_FORCE_OBJECT));
$proj_longitude_json=escapeshellarg(json_encode($proj_longitude, JSON_FORCE_OBJECT));


$path=realpath('../Python/traverse_to_KML.py');	
$python_path=realpath("C:/Python33/python.exe");
$command=escapeshellcmd("$python_path $path");

$full_command="$command $lat_not_corr_json $lon_not_corr_json $proj_latitude_json $proj_longitude_json $base_coor[1] $base_coor[1]";

//Python process
$temp=shell_exec($full_command);
$result=explode("::",$temp);
$kml_name_non_corrected=$result[0];
$kml_name_corrected=$result[1];

//writing the tolerance

if($traverse_tolerance>=$tolerance) {
    $tolerance_message='<br><span style="color:#00ff00;">Your taverse does not meet the requirement accuracy</span><br>';
}
else{
    $tolerance_message='<br><span style="color:#ff0000;">Your taverse does not meet the requirement accuracy</span><br>';
}

        
/////////////////////printing the report//////////////////////////////////
$admin=$_SESSION['admin']; // defines if it is an administrator or a User  
$i=1;
foreach ($departures as $v) {
     $departures_round[$i]=round($v, $precision=3);
     ++$i;
 }
 unset($v);
 $i=1;
 foreach ($latitudes as $v) {
     $latitudes_round[$i]=round($v, $precision=3);

     $i++;
 }
 unset($v);
 $i=1;
foreach ($correct_departures as $v) {
    $correct_departures_round[$i]=round($v, $precision=3);
    $i++;
}
unset($v);
$i=1;
foreach ($correct_latitudes as $v) {
    $correct_latitudes_round[$i]=round($v, $precision=3);
    $i++;
}
unset($v);
$i=1;
foreach ($proj_latitude as $v) {
    $proj_latitude_round[$i]=  round($v, $precision=3);

    $i++;
}
unset($v);
$i=1;
foreach($proj_longitude as $v){
 $proj_longitude_round[$i]=round($v, $precision=3);   
$i++;

}
unset($v);

if($traverse_type=="1"){
    echo "You started in $base_coor[1] and finished in $base_coor[2]<br><br>";
}
else{
    echo "You started and finished in '$base_coor[1]'<br><br>";
}

switch ($admin){
    case 0:
        echo "Residual of departures: $residual_dep<br><br>";
        echo "Residual of Latitudes: $residual_lat<br><br>";
        echo "Linear misclouse: $linear_misclousure <br><br>";
        echo "Traverse lenth: $sum_distances<br><br>";
        echo "Traverse relative precision 1: $traverse_tolerance<br>";
        break;
    case 1:
        echo "Residual of departures: $residual_dep<br><br>";
        echo "Residual of Latitudes: $residual_lat<br><br>";
        echo "Linear misclouse: $linear_misclousure <br><br>";
        echo "Traverse lenth: $sum_distances<br><br>";
        echo "Traverse relative precision 1: $traverse_tolerance<br><br>";

        $report=$report.'<table border="1px"><tr><th>--</th><th>--</th><th>--</th><th colspan="2">Unajusted</th><th colspan="2">Balanced</th><th colspan="2">Coordinates</th></tr>';    
        $report=$report.'<tr><th>Station</th><th>Pre. Azimuts</th><th>Length</th><th>Departures</th><th>Latitude</th><th>Departure</th><th>Latitude</th><th>X</th><th>Y</th></tr>';
        $report=$report."<tr><td>$base_coor[1]</td><td>--</td><td>--</td><td>--</td><td>--</th><td>--</td><td>--</td><td>$proj_longitude_round[1]</td><td>$proj_latitude_round[1]</td></td>";
        $counter1=2;
        for($i=1;$i<=$number_dist_ang;$i++){

               $report=$report."<tr><td>--</td><td>".$angle[$i][deg]."d ".$angle[$i][min]."m ".$angle[$i][seg]."s "."</td><td>$dist[$i]</td><td>$departures_round[$i]</td><td>$latitudes_round[$i]</td><td>$correct_departures_round[$i]</td><td>$correct_latitudes_round[$i]</td><td>--</td><td>--</td></tr>";
               if($i<$number_dist_ang){
                       $report=$report."<tr><td>$i</td><td>--</td><td>--</td><td>--</td><td>--</th><td>--</td><td>--</td><td>$proj_longitude_round[$counter1]</td><td>$proj_latitude_round[$counter1]</td></td>";
               }
               else{
                   $report=$report."<tr><td>$base_coor[2]</td><td>--</td><td>--</td><td>--</td><td>--</th><td>--</td><td>--</td><td>$proj_longitude_round[$counter1]</td><td>$proj_latitude[$counter1]</td></td></table>";
               }
                ++$counter1;
        }
        echo $report;
        break;
 }    
 
 
 
$display_result='<div class="row" align="center"><a class="btn btn-success" onclick="display_traverse()">Display traverse</a></div>';
echo '<a style="display:none" id="kml_location">KMLS/'.$KML_name.'</a><>';
$kmlpath1='http://gaia.gge.unb.ca/jaime/GEOWAPP/KMLS/'.$kml_name_non_corrected;
$kmlpath2='http://gaia.gge.unb.ca/jaime/GEOWAPP/KMLS/'.$kml_name_corrected;
echo "<div><h2>KML files</h2></div><br>";
echo "<div>Non corrected traverse  <a id='kmlpath1'>$kmlpath1</a></div><br>";//''
echo "<div>Corrected traverse  <a id='kmlpath2'>$kmlpath2</a></div><br>";//

echo "<br>";
echo '<div align="center" class="wrapper">'.$display_result.'</div><br>';

echo '<div id="check_box"><div>';
echo '<br><br><br><br><br>';    
?>

