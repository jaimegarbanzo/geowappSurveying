<script type="text/javascript">
    function back_lsq(){
          $("#FormDisplayer").load('Forms/form_leveling_lsq.php');
      }
     function lsq_proc(){
        var data=$("#form").serialize();
        $.get("PHPS/leveling_least_squares.php",data)
            .done(function( data ) {
                $("#FormDisplayer").html(data);
            });
        }
</script>

<?php
$number_of_points=$_GET["number_point_lsq"];		
$number_known_bms=$_GET["number_bms"];

if(is_numeric($number_of_points) && is_numeric($number_known_bms)) {
        $validator=true;		
}	
else {
        $validator=false;	
}	

        
if($validator==true) {
			
    $form_tag1='<form id="form" method="get">';
    $form_tag2='</form>';

    $table_tag1='<table>';
    $table_tag2='</table>';

    $input_tag1_point_code_from='<input type="text" name="';
    $input_tag2_point_code_from='" size="6px"/>';

    $input_tag1_point_code_to='<input type="text" name="';
    $input_tag2_point_code_to='" size="6px"/>';		

    $input_tag1_height_diff='<input type="text" name="';
    $input_tag2_height_diff='" size="8px"/>';	

    $input_tag1_distance='<input type="text" name="';
    $input_tag2_distance='" size="8px"/>';		
    $submit_buttom='<input type="button" value="submit" onclick="lsq_proc()">';

    for($i=1; $i<=$number_of_points; $i++) {

        if($i== 1) {

        // This part opens up the form

            $leveling_form=$leveling_form.$form_tag1;

            // this part the headers of the table are defined in order to create a form
            //for recording the data of the traverse.
            $leveling_form=$leveling_form.$table_tag1.'<tr>'.'<th>'.'line'.'</th>';
            $leveling_form=$leveling_form.'<th>'.'From (m)'.'</th>';
            $leveling_form=$leveling_form.'<th>'.'to (m)'.'</th>';
            $leveling_form=$leveling_form.'<th>'.'Distance'.'</th>';
            $leveling_form=$leveling_form.'<th>'.'Height Difference'.'</th>'.'</tr>';
        }

       $leveling_form=$leveling_form.'<tr>'.'<td>'."<h4> $i<h4>".'</td>';
        $leveling_form=$leveling_form.'<td>'.$input_tag1_point_code_from."code_from[$i]".$input_tag2_point_code_from.'</td>';
        $leveling_form=$leveling_form.'<td>'.$input_tag1_point_code_to."code_to[$i]".$input_tag2_point_code_from.'</td>';
        $leveling_form=$leveling_form.'<td>'.$input_tag1_distance."dist[$i]".$input_tag2_distance.'</td>';
        $leveling_form=$leveling_form.'<td>'.$input_tag1_height_diff."height_dif[$i]".$input_tag2_height_diff.'</td></tr>';

        //$leveling_form=$leveling_form.'<td>'.$input_tag1_minus."minus[$i]".$input_tag2_minus.'</td>';	
        //	$leveling_form=$leveling_form.'<td>'.$input_tag1_distance."dist[$i]".$input_tag2_distance.'</td></tr>';	

    }	

   for($i=1; $i<=$number_known_bms; $i++) {
            $leveling_form=$leveling_form."<tr><td>$i</td>".'<td colspan="3">Bench Mark code  <input type="text" name="';
            $leveling_form=$leveling_form."BM[$i]".'" size="8px"></td></tr>';

    }
    // adding the Weight contant
          $leveling_form=$leveling_form.'<tr><td colspan="4">Weight Constant <input type="text" name="w_const" size="8px" value="1"/></td></tr>';

        //hidden values 
    $leveling_form=$leveling_form.'<input type=hidden name="number_of_points" value="'."$number_of_points".'" />';
    $leveling_form=$leveling_form.'<input type=hidden name="number_known_bms" value="'."$number_known_bms".'" />';					

   //Add the submit bootom 
        $leveling_form=$leveling_form.'<tr>'.'<td>'.$submit_buttom.'</td>'.'</tr>';		

        // end of the table		   
   $leveling_form=$leveling_form.$table_tag2;

    $leveling_form=$leveling_form.$form_tag2;

    echo "$leveling_form";
		
			
}else {
    echo '<h3><span style="color:red;">Please input a number</span></h3>';

    echo '<br>';
    echo '<h3><a onclick="back_lsq()">Return</a></h3>';
} 
echo "<br><br><br><br><br><br>"
        
?>