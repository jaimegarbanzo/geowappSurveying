<script type="text/javascript">
    function back(){
           $("#FormDisplayer").load('Forms/form_leveling_check.php');
       }
    function posting_comp_lev(){
        var data=$("#form").serialize();
        $.get("PHPS/compare_leveling_work.php",data)
            .done(function( data ) {
                $("#FormDisplayer").html(data);
            });
            
    }
</script>

<?php

// this part validate he data input
//all the values have to be numeric
	
$number_tps_forw=$_GET["number_tps_forw"];
$number_tps_back=$_GET["number_tps_back"];
if(is_numeric($number_tps_forw) && is_numeric($number_tps_back)) {	
        $validator=true;
}
else {
        $validator=false;
}
                
if($validator==true) {
						
    // these variables are used to create the form and another HTML tags
    $form_tag1='<form id="form" metod="get">';
    $form_tag2='</form>';


    // input tags
    // the observations that should be positive in a leveling 				
    $input_tag1_plus='<input type="text" name="';
    $input_tag2_plus='" size="8px"/>';

    // the numbers that should be positive in a leveling 
    $input_tag1_minus='<input type="text" name="';
    $input_tag2_minus='" size="8px"/>';

    // the distance between tps and BMs 
    $input_tag1_distance='<input type="text" name="';
    $input_tag2_distance='" size="8px"/>';		

    $table_tag1='<table>';
    $table_tag2='</table>';		

    $submit_buttom='<input type="button" value="submit" onclick="posting_comp_lev()">';

    $tp_bm_index=1;
    $dist_index=1;

    // This part opens up the form
    $leveling_form=$leveling_form.$form_tag1;				
    $leveling_form=$leveling_form.'<h4>Input the BM Code</h4>';		
    $leveling_form=$leveling_form.$table_tag1;	
    $leveling_form=$leveling_form.'<tr><td><h4>BM1 <input type="text" name="BM1" size="8px"/></h4></td>';
    $leveling_form=$leveling_form.'<td><h4>BM2 <input type="text" name="BM2" size="8px"/></h4><td><tr>';		

    for($i=1; $i<=$number_tps_forw; $i++) {
            if($i==1) {

                            // this part the headers of the table are defined 
                            $leveling_form=$leveling_form.$table_tag1.'<tr>'.'<th>'.'Station'.'</th>';
                            $leveling_form=$leveling_form.'<th>'.'B.S. + (m)'.'</th>';
                            $leveling_form=$leveling_form.'<th>'.'F.S. - (m)'.'</th>';
                            $leveling_form=$leveling_form.'<th>'.'Distance (Km)'.'</th>'.'</tr>';

                            $leveling_form=$leveling_form.'<tr><td><h4>BM1</h4></td>'; 
                            $leveling_form=$leveling_form.'<td>'.$input_tag1_plus."plus_forw_BM1".$input_tag2_plus.'</td></tr>';	

            }

            $leveling_form=$leveling_form.'<tr><td colspan="3"></td>';
            $leveling_form=$leveling_form.'<td>'.$input_tag1_distance."dist_forw"."[$i]".$input_tag2_distance.'</td></tr>';
            $leveling_form=$leveling_form.'<tr>'.'<td>'."<h4>TP $i<h4>".'</td>';

            $leveling_form=$leveling_form.'<td>'.$input_tag1_plus."plus_forw"."[$i]".$input_tag2_plus.'</td>';
            $leveling_form=$leveling_form.'<td>'.$input_tag1_minus."minus_forw"."[$i]".$input_tag2_minus.'</td></tr>';

            if($i==$number_tps_forw) {		
                    $last_dist_forw=$i+1;
                    $leveling_form=$leveling_form.'<tr><td colspan="3"></td>';
                    $leveling_form=$leveling_form.'<td>'.$input_tag1_distance."dist_forw"."[$last_dist_forw]".$input_tag2_distance.'</td></tr>';						

                    $leveling_form=$leveling_form.'<tr><td colspan="1"><h4> BM2</h4> </td>';
                    $leveling_form=$leveling_form.'<td>'.$input_tag1_plus."plus_back_BM2".$input_tag2_plus.'</td>';
                    $leveling_form=$leveling_form.'<td>'.$input_tag1_minus."minus_forw_BM2".$input_tag2_minus.'</td></tr>';							
            }

    }


    $return_run=$number_tps_forw+1;	

    for($i=1; $i<=$number_tps_back; $i++) {

            $leveling_form=$leveling_form.'<tr><td colspan="3"></td>';
            $leveling_form=$leveling_form.'<td>'.$input_tag1_distance."dist_back"."[$i]".$input_tag2_distance.'</td></tr>';
            $leveling_form=$leveling_form.'<tr>'.'<td>'."<h4>TP $return_run<h4>".'</td>';

            $leveling_form=$leveling_form.'<td>'.$input_tag1_plus."plus_back"."[$i]".$input_tag2_plus.'</td>';
            $leveling_form=$leveling_form.'<td>'.$input_tag1_minus."minus_back"."[$i]".$input_tag2_minus.'</td></tr>';

            if($i==$number_tps_back) {					
                    $last_dist_back=$i+1;
                    $leveling_form=$leveling_form.'<tr><td colspan="3"></td>';
                    $leveling_form=$leveling_form.'<td>'.$input_tag1_distance."dist_back"."[$last_dist_back]".$input_tag2_distance.'</td></tr>';						

                    $leveling_form=$leveling_form.'<tr><td colspan="2"><h4> BM1</h4> </td>';
                    $leveling_form=$leveling_form.'<td>'.$input_tag1_minus."minus_back_BM1".$input_tag2_minus.'</td></tr>';							


            }
            ++$return_run;
    }



    $leveling_form=$leveling_form.'<tr>'.'<td>'.$submit_buttom.'</td>'.'</tr>';

    $leveling_form=$leveling_form.$table_tag2;


    // hidden values

    $leveling_form=$leveling_form.'<input type=hidden name="leveling_option" value="'."$leveling_option".'" />';
    $leveling_form=$leveling_form.'<input type=hidden name="number_tps_forw" value="'."$number_tps_forw".'" />';
    $leveling_form=$leveling_form.'<input type=hidden name="number_tps_back" value="'."$number_tps_back".'" />';

        $leveling_form=$leveling_form.$form_tag2;

        echo "$leveling_form";					
				
				
}else {
    echo '<h3><span style="color:red;">Please input a number</span></h3>';
    echo '<br>';
    echo '<h3><a onclick="back()">Return</a></h3>';  
}
echo "<br><br><br><br><br><br>";

?>