
<?php 
    session_start();
    /* Set internal character encoding to UTF-8 */
    
    mb_internal_encoding("UTF-8");
        
    $code_from_array=$_GET["code_from"];
    $code_to_array=$_GET["code_to"];		
    $dist_array=$_GET["dist"];	
    $height_diff_array=$_GET["height_dif"];
    $BM_known=$_GET["BM"];
    $length_known_BM=$_GET["number_known_bms"];
    $length_other_arrays=$_GET["number_of_points"];
    $weight_constant=$_GET["w_const"];
    $counter1=0;
    $counter2=0;
	
 // this two funtion trim all the spaces in the submited data
   
    foreach ($code_from_array as &$value) {
        $value=trim($value);
    }
    
    unset($value);
    
    foreach ($code_to_array as &$value) {
        $value=trim($value);
    }
    
    unset($value);
     
////////////////////////////////////////////////////////////////////
//////////////////Start Database Connection ///////////////////////    
///////////////////////////////////////////////////////////////////

                
    $connect=mysqli_connect("yourServer", "yourID", "yourPass","yourDataBase");

    if(mysqli_connect_errno()){

        die('Cound not connect'.mysql_error());
    }
    
    
    for ($i=1; $i<=$length_known_BM; $i++){
        $BM_code=$BM_known[$i];
        $query=mysqli_query($connect,'select * from `yourDataBase`.`bench_mark` where `code`='.'"'.$BM_code.'"'); 
   
        $num_rows= mysqli_num_rows($query);

        if(!$num_rows){
            die("connection lost with the database");
             }
        while ($rows = mysqli_fetch_array($query)) {
            $BM_ARRAY[$i]=$rows['z'];
        }
        $check=$check+1;
     }
    
    mysqli_close($connect);  
    
 ////////////////////////the data base connection ends/////////////////////////
 
 // this values will be querried from a database	

    //$BM_ARRAY=array(107.50,100);
    $number_collumns=1;
	
// this counts how many different station are in the observation;
    $array_merged=array_merge($code_from_array,$code_to_array);	
	
// by applying array_count_values we are eliminating the repeated values
    $counting=array_count_values($array_merged);
 
// this determines how many collunms are in the coeficient matrix
    $number_collumns=count($counting, $mode = null);//-count($BM_known, $mode=null);			
  
	// set the current value to the first value in the array
    reset($counting);
	
 // this for separates the unknown values an stored in to an array
 // these stored values will be used as header of the coeficient matrix for 
 // the least squares ajustment
 // example
 // collunm array (X Y Z W) known values (X W)
 // result = array (Y Z)  
 
 // this parameter sets the index for the unknown values 	
 $collumn_index=1;	
	 
 
 for($i=1; $i<=$number_collumns; $i++) {
		
    if(in_array(key($counting), $BM_known)===FALSE) {
      	$collumn_name[$collumn_index]=key($counting);
        $collumn_index++;
    }
     next($counting); 				
}

// number of unknown values
$number_unknown_values=count($collumn_name);	
	
	// this for creates the matrix of coeficients if 
	// with out the known points, which are going to be add in the
	// right hand side of the equation.
	// for example
	// X -BM1 = +10  and BM1 is known
	//	Y-X=-11
	// Y-X=12
	// result 
	//   ([X]=>-1 [Y]=>0)=10-BM1
	//   ([x]=>-1 [Y]=>1)=-11
	//		([x]=>1 [Y]=>-1)=12
	
    for($i=1; $i<=$number_unknown_values; $i++) {	
		
        for($j=1; $j<=$length_other_arrays; $j++) {
				
            if(strcmp($collumn_name[$i], $code_from_array[$j])===0) {
                $coeficient_matrix[$j][$collumn_name[$i]]=-1;
            }
            elseif(strcmp($collumn_name[$i], $code_to_array[$j])===0) {
                $coeficient_matrix[$j][$collumn_name[$i]]=1;
            }
            else {
                $coeficient_matrix[$j][$collumn_name[$i]]=0;
            }					
    }
}
	
 //this for creates the matrix of weights
	 
  for($i=1; $i<=$length_other_arrays; $i++) {	
	
	for($j=1; $j<=$length_other_arrays; $j++) {
            if($i===$j) {
			$weight_matrix[$j][$i]=$weight_constant/$dist_array[$i];
                        $weight_vector[$i]=$weight_constant/$dist_array[$i];
            }
            else {
		$weight_matrix[$j][$i]=0;
            }	
        }
    }	
      
    // forming the L_matrix with is the observations     
    
    $known_values=count($BM_known);
    
    reset($BM_ARRAY);
    
    $observed_vector=$height_diff_array;
    foreach ($BM_known as &$value) {	
		
        for($j=1; $j<=$length_other_arrays; $j++) {
            if(strcmp($value, $code_from_array[$j])===0) {
                $observed_vector[$j]=$observed_vector[$j]+current($BM_ARRAY);
            }
            elseif(strcmp($value, $code_to_array[$j])===0) {
                $observed_vector[$j]=$observed_vector[$j]-current($BM_ARRAY);
            }
            else {
                $observed_vector[$j]=$observed_vector[$j];
            }					
        }
        next($BM_ARRAY);
    } 

        
	// least squares formula (At W A)=NX=ATWL
	// passing the variable to Python in order to do linear algebra operations 
	// enconding the arrays into json format
        
	$coef_mat_json=  escapeshellarg(json_encode($coeficient_matrix, JSON_FORCE_OBJECT));	
        $observed_vec_json=  escapeshellarg(json_encode($observed_vector,JSON_FORCE_OBJECT));
	$weight_matrix_json= escapeshellarg(json_encode($weight_matrix, JSON_FORCE_OBJECT));	
	$degrees_freedon=  escapeshellarg($length_other_arrays-$number_unknown_values);
        
	// getting the absolute path
	$path=realpath('../Python/matrix_mult.py');	
	$python_path=realpath("C:/Python33/python.exe");
	$command=escapeshellcmd("$python_path $path");
        $full_command="$command $coef_mat_json $weight_matrix_json $observed_vec_json $degrees_freedon";
	
	//Python process
	$temp=shell_exec($full_command);
            //returns [X matrix] [Residuals] and [standart dev]
	
        //
        $x_residual_stdv=explode('::', $temp);
        reset($x_residual_stdv); 
        $elevation=  current($x_residual_stdv);
        $elevation= explode(',', $elevation);
        next($x_residual_stdv);
        $deviation=current($x_residual_stdv);
        $deviation=  explode(',', $deviation);
        next($x_residual_stdv);
        $residuals=current($x_residual_stdv);
        $residuals=  explode(',', $residuals);
        reset($x_residual_stdv);        
        
        
        echo '**********************results***************************' ;
        $counter1=0;
        for ($i=1; $i<=$length_other_arrays;$i++){
            if($i==1){    
                $report="<table border='1px'><tr><th>From</th><th>to</th><th>Dist</th><th>Observation Eq</th><th>Weight</th><th>Residuals</th></tr>";    
                }
  
           $report=$report."<tr><td>$code_from_array[$i]</td><td>$code_to_array[$i]</td><td>$dist_array[$i]</td><td>$observed_vector[$i]</td><td>$weight_vector[$i]</td><td>$residuals[$counter1]</td></tr>";
            
           $counter1++;
        }
        $report=$report."</table>";
	
        echo $report.'<br>';
        
        
        $unknown_number=  count($elevation);
        $counter1=1;
        for($i=0;$i<$unknown_number;$i++){
            if($i==0){
                $report2="<table border='2px'><tr><th>Station</th><th>Elevation</th><td>st. dev.</td></tr>";
            }
            $report2=$report2."<tr><td>$collumn_name[$counter1]</td><td>$elevation[$i]</td><td>$deviation[$i]</td></tr>";
            $counter1++;    
                    
            
        }
        $report2=$report2."</table>";
        echo $report2;
?>