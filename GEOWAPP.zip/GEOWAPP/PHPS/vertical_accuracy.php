
<?php
/// this funtion will a function for processing a function
$time1=  time();
//getting information about the sample name
$sample_name=trim($_POST["sample_name"]);
//getting information about the file submited
$name=$_FILES["file"]['name'];
$temp_name=$_FILES["file"]['tmp_name'];
$size=$_FILES["file"]['size'];
$error=$_FILES['file']['error'];
$max_size=500000;
$closest_points=$_POST["closest_points"];
$accuracy_required=$_POST["accuracy"];

// strip the extension of the file
$extension=  strtolower(substr($name, strpos($name, ".")+1));

// save the files in the server

if (isset($name)){// check whether the variable has been set
    if(!empty($name)){// check wheter the variable is not null
        
        if($extension==="txt"||$extension==="csv" && $size<=$max_size){
            $location=  realpath('../uploads/vertical_check/');// location where the file will be store

            if(move_uploaded_file($temp_name, $location."//".$name)){// the doble slashes if for one to escape //=/
                echo '<ul><li>File uploaded.</li></ul>';
                
            }
            else{
                echo '<h3>Error uploadding the file <a href="../Forms/vertical_checking_form.html">return</a></h3> <br>';
                if($error){
                    switch ($error){
                        case 1;
                            echo 'The uploaded file exceeds the max file directive(PHP)';
                            break;
                        case 2:
                            echo 'The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form';
                            break;
                        case 3:
                            echo 'The uploaded file was only partially uploaded';
                            break;
                        case 4:
                            echo 'No file was uploaded';
                            break;
                        case 6:
                            echo 'Missing a temporary folder. Introduced in PHP 4.3.10 and PHP 5.0.3';
                            break;

                        case 7:
                            echo 'Failed to write file to disk';
                            break;
                }
                }
            }
        } else{
            echo '<h3>Just txt and csv extensions are accepted <a href="../Forms/vertical_checking_form.html">return</a></h3>';
            die();
        }
        
    }

    else {
         echo '<h3>Please choose a File <a href="../Forms/vertical_checking_form.html">return</a></h3>';
         die();
    }
}
else{
    echo "<h3>Internal error variable (name) has not been set</h3>";
    die();
}

// defining the location of the uploaded file
$full_location=$location."\\".$name;

// defining the location of the sample
$samplelocation=realpath("../uploads/vertical_samples")."\\";

// check if the sample file exist in the directory
$samplelocation=  csvortxtexist($samplelocation, $sample_name);

// escaping the file path to python

$samplelocation_esc= addslashes($samplelocation);
$full_location_esc=  addslashes($full_location);

// preparing to execute python
$path=realpath('../Python/vertical_acuracy.py');
$python_path=  realpath('C:\Python33\python.exe');
$command=escapeshellcmd("$python_path $path");
$full_command="$command $samplelocation_esc $full_location_esc $accuracy_required $closest_points";

//Python process
    $temp=shell_exec($full_command);
// unsetting variables
    unset($path);    
    unset($command);    
    unset($full_command);
    unset($samplelocation);    
    unset($samplelocation_esc); 
    unset($full_location);
    
$result=explode("::",$temp);

unset($temp); 

$KML_name=$result[0]; $report_name=$result[1];$processing_time=$result[2];

unset($result);
echo "<ul><li>File processed (processing time = $processing_time seg)</li></ul><br><br>";

echo '<br>';
$download_report='<div class="row" align="center"><a class="btn btn-info" target="_blank" href="REPORTS/'.$report_name.'">Download Report</a></div>';
$display_result='<div class="row" align="center"><a class="btn btn-success" onclick="display_poly()">Display Acuracy Polygons</a></div>';
echo '<a style="display:none" id="kml_location">KMLS/'.$KML_name.'</a><>';
$kmlpath='yourServer/jaime/GEOWAPP/KMLS/'.$KML_name;
echo "<div id='kmlpath'>$kmlpath</div>";

echo '<div align="center" class="wrapper">'.$download_report.'<br>'.$display_result.'</div>';


echo '<br><br><br><br><br>';

// this funtion checks if the sample file  exist
function csvortxtexist($samplelocation,$sample_name){
    if(file_exists($samplelocation.$sample_name.".txt")){
        return $samplelocation.$sample_name.".txt";

    }elseif(file_exists($samplelocation.$sample_name.".csv")){
        return $samplelocation.$sample_name.".csv";
    }else{
        echo '<ul><li>the sample can not be found. Check the sample file name againg <a href="Forms/vertical_checking_form.html">return</a></li></ul>';
        die();
    }
}

?>