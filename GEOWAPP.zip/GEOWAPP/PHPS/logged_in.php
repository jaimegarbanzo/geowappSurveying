<html>
    <head>
        <script src="js/libs/jquery/jquery.js"></script>
    </head>
<body>
<?php
session_start();
if($_REQUEST["email"]&&$_REQUEST["password"]){
    
    $email=trim($_REQUEST["email"]);
    $password=trim($_REQUEST["password"]);
    
    $connect=mysqli_connect("yourServer", "yourID", "yourPass","yourDataBase");
        
        if(mysqli_connect_errno()){
            
            die('Cound not connect'.mysql_error());
        }

    $query=mysqli_query($connect,"SELECT * FROM `yourDataBase`.`users` WHERE `email`='$email'");   
    
    $num_rows= mysqli_num_rows($query);
        mysqli_close($connect);
    if(!$num_rows){
           die('This email is not attached to any acount');
        }
    while ($rows = mysqli_fetch_array($query)) {
        $dbusername=$rows['name'];
        $dbpassword=$rows['password'];
        $dbadmin=$rows['admin'];
        
    }
    
    if ($password===$dbpassword){
        $_SESSION['username']=$dbusername;
        $_SESSION['admin']=$dbadmin;
        echo '<script type="text/javascript">
                    window.location = "../index.php"
             </script>';
    }
    else {
         die('the password does not match the records');
        }

 }
 else {
     echo "Missing email or password";
}
?>
 
</body>
</html>