<?php
	$name=$_POST["uname"];
	$usurname=$_POST["usurname"];
	$email=$_POST["email"];
	$password=trim($_POST["password"]);
	$passwordcheck=trim($_POST["passwordcheck"]);
        $admin="0";
	
        if (strcmp($password, $passwordcheck)){
            die("Passwords are not the same. Do not use spaces");
            
        }
        
        if (strlen($password)< 4){
            die('Password has to be at least 4 characters');
        }
        
        
        if(!(strlen($name)*  strlen($usurname)* strlen($email)*strlen($password)* strlen($passwordcheck))){
           die('Please fill all the blanks'); 
        }
        
        
	$connect=mysqli_connect("yourDataBase", "yourID", "yourPass","yourDataBase");
        
        if(mysqli_connect_errno($connect)){
            
            die('Cound not connect error='.mysql_error());
        }
       
       $query_val=mysqli_query($connect,"SELECT * FROM `sp_geowapp`.`users`  WHERE email='$email'");
       
       if(!$query_val){
           die('This user already is already included in the database');
       }
       
       $query=mysqli_query($connect,"INSERT INTO `yourDatabase`.`users` (ID,name,surname,email,password,admin) VALUES ('0','$name', '$usurname','$email','$password', '$admin')");
        
      if(!$query){
        die('Elements could not be inserted error= '.mysqli_error($connect));
      }
	
       echo "Element inserted";
       mysqli_close($connect);
?>