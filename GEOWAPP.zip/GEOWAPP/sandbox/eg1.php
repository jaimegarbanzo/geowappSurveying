<?php 

$A=scandir('../uploads/vertical_samples');

echo var_dump($A);