<!DOCTYPE html>
<!--
http://stackoverflow.com/questions/17409598/toggle-multiple-kml-kml-layers-in-google-maps-api-v3
GEOWAAPP PROJECT FOR M.Sc. Geomatics Engineering UNB
-->
<html>
    <?php session_start();?>
    <head>
        <title>GEOWAPP</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/geoapp.css"/>
        <link rel="stylesheet" href="css/bootstrap.min.css"/>
        <script src="js/libs/bootstrap/bootstrap.min.js"></script>
        <script src="js/libs/jquery/jquery.js"> </script>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"> </script>
       
        <!-- jquery functions-->
        <script>
            // DISPLAY MENUS And hides the menus
            
            $(document).ready(function(){   
                $('#survey_toolbox').hide();
                $(".sublist").hide();
                $('ul li.list > a')
                .attr('data-active','0')
                .click(function(event){
                   $('.sublist').hide();    
                    if($(this).attr('data-active')==0){
                        $(this).parent().find('ul').slideToggle('slow');
                        $(this).attr('data-active','1');
                    }
                    else
                      $(this).attr('data-active','0');        
                });
                $('a.btn btn-default').click(function(){
                    $('a.btn btn-default').removeClass("active");
                    $(this).addClass("active");
                });
                
                $('#survey_toolbox_bottom').click(function(){
                    
                    $("#survey_toolbox").toggle();
                        
                 });
                 
                 
            });
            
            // this display ot hide the tools if the user is logged in.
            $(document).ready(function(){
                var username=<?php $username=$_SESSION['username']; echo json_encode($username);?>;
                var admin=<?php $admin=$_SESSION['admin']; echo json_encode($admin); ?>;
                if (username){
                        $("#logged_in").html('<div style="color: whitesmoke;" class="navbar-form navbar-right"> Hi, '+username+"!. You are logged in "+ "<a href='PHPS/log_out.php'>log out</a><div>"); 
                        $("#FormDisplayer").html('<div><h3>Welcome to the GEOAPP for enhancing the survey practicums</h3></div>');
    
                       }
                else{
                    $('#survey_toolbox_bottom').hide();
                }
            });
                    
            function traversing1(){
                $("#FormDisplayer").load("Forms/Form1_traverse_type.php");
            };
            function leveling1(){
                $("#FormDisplayer").load('Forms/form_leveling_check.php');
            };
            function leveling2(){
                $("#FormDisplayer").load('Forms/form_leveling_lsq.php');
            };
            function vertical_check(){
              $("#FormDisplayer").load('Forms/vertical_checking_form.html');
            };
          
            function alert1(){
                $("#FormDisplayer").load('Forms/horizontal_checking_form.php');
            };
           
            // Registry functions
            function register(){
                window.open('Forms/registerform.html');
                
            };    
            function print_w(){
              var content= document.getElementById("main_window").innerHTML;
           
              window.open().document.write(content); 
              
             // new_element.document.open();
             // new_element.document.write(content.innerHTML);
              //new_element.document.close();
              //new_element.focus();
              //window.print();
            };
            function Clear_map(){
                $('#MapDisplayer').remove();
                
            };
            
            
        </script>
        
        <script type="text/javascript" 
               src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAmpAzpSDd5JCuqhEut_g6dlUkZMWdkr9U">
            
        </script>
        <script>
            var layers=[];
            var map;
            
            function display_poly(){
                var kmlname=$("#kmlpath").text();
              
                var fredy = new google.maps.LatLng(45.953578,-66.658441);
                $("#main_window").append('<br><br><div id="MapDisplayer" style="height:500px;padding-top:10px"></div>');
                var mapOptions = {
                  zoom: 11,
                  center: fredy
                };

                map = new google.maps.Map(document.getElementById('MapDisplayer'), mapOptions);

                var KML_file = new google.maps.KmlLayer({
                  url: kmlname
                });
                
                KML_file.setMap(map);
            }
                
                          
            function display_traverse(){
                var kmlpath1=$('#kmlpath1').text();//'http://gaia.gge.unb.ca/jaime/GEOWAPP/KMLS/KML_adjustedd8476.kml'//
                var kmlpath2=$('#kmlpath2').text();//'http://gaia.gge.unb.ca/jaime/GEOWAPP/KMLS/KML_non_adjustedf2448.kml'//
                layers[0]=new  google.maps.KmlLayer(kmlpath1,
                            {preserveViewport: true});
                layers[1]=new  google.maps.KmlLayer(kmlpath2,
                            {preserveViewport: true});
                            
                var fredy = new google.maps.LatLng(45.953578,-66.658441);
                $("#check_box").html('Non Adjusted Traverse <input type="checkbox" id="layer_01" onclick="toggleLayers(0);"/> Adjusted Traverse<input type="checkbox" id="layer_02" onclick="toggleLayers(1);"/>'); 
                
                $("#main_window").append('<br><br><div id="MapDisplayer" style="height:500px;padding-top:10px"></div>');
                var mapOptions = {
                  zoom: 11,
                  center: fredy
                };

                map = new google.maps.Map(document.getElementById('MapDisplayer'), mapOptions);
                  
            }
            function toggleLayers(i){
                if(layers[i].getMap()==null) {
                        layers[i].setMap(map);
                }
                else {
                    layers[i].setMap(null);
                }
            }
           google.maps.event.addDomListener(window, 'load', initialize);
    </script>
        
        
    </head>
    <body style="height: 100%; width:100%;">
     <!-- The navigation bar begins-->
     <div class="navbar navbar-inverse navbar-fixed-top" role="navigation" >
            <div class="container">
               
              <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                  <span class="sr-only">Toggle navigation</span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">GEOWAPP</a>
                <a href="http://www.unb.ca/"> 
                     <img style="position:relative;" src="img/logo_small.png"/>
                </a>
              </div>             
              <div id="logged_in" class="navbar-collapse collapse">
                  <form class="navbar-form navbar-right" role="form" action="PHPS/logged_in.php">
                    <div class="form-group">
                      <input name="email" id="email" type="text" placeholder="Email" class="form-control">
                    </div>
                    <div class="form-group">
                      <input id="Password" name="password" type="password" placeholder="Password" class="form-control">
                    </div>
                    <button id="submit_em_pass" type="submit" class="btn btn-success" onclick="signIN()">Sign in</button>
                  </form>
                    
              </div><!--/.navbar-collapse -->
               <div class="btn btn-link" style="position:fixed; right:0px; top: 0px;"><a onclick="register()"><h4>register</h4></a></div> 
             </div>
            
       </div>
     <!-- the navigation bar ends -->
     <!-- line dividing the  the two sections-->
        <div class="jumbotron" style="background-color:#E80000;">
        
        </div>
     <!-- end of line--> 
     
     <div class="container" style="">  
            <div class="main_window" id="main_window">
                <div  id="FormDisplayer">
                <h3>Please Sign IN for accessing the toolbox </h3>
                </div>
                </div>
         
           <div id="survey_toolbox_bottom" style="position: fixed; right:0px;" class="btn btn-primary" onClick="survey_tool_hiden()"> Survey tools</div><br> <br>    
           
           <div id="survey_toolbox" class="container" style="position: fixed; right: 0px; text-align: right; width: 25%;">
                <ul>
                    <li class="list"><a  class="btn btn-l">Traversing (1)</a>
                        <ul class="sublist">
                            <li><a class="btn btn-default" id="traversing_element_1" onclick="traversing1()">Check your traverse</a></li>                            
                        </ul>
                    </li>
                    <li class="list"><a class="btn btn-toolbar">Leveling (2)</a>
                        <ul class="sublist">
                            <li>
                                <a class="btn btn-default" id="leveling_element_1" onclick="leveling1()">Check out your leveling</a>
                            </li>
                            <li>
                                <a class="btn btn-default" id="leveling_element_1" onclick="leveling2()">Least Squares Tool</a>
                            </li>
                        </ul>

                    </li>
                    <li class='list'><a  class="btn btn-toolbar">Horizontal checking (1)</a>
                        <ul class="sublist">
                            <li><a class="btn btn-default" onclick="alert1()">Overall accuracy</a></li>                            
                        </ul>
                    </li>
                    <li class='list'><a  class="btn btn-toolbar">Vertical checking (1)</a>
                        <ul class="sublist">
                            <li><a class="btn btn-default" onclick="vertical_check()">Vertical Accuracy</a></li>                            
                        </ul>
                    </li>
                </ul> 
            </div>   
            <div id="print_main" style="position: fixed; left:0px;" class="btn btn-link" onClick="print_w()"> Print Main <br> Window</div><br> <br>
            <div id="ClearMap" style="position: fixed; left:0px;" class="btn btn-link" onClick="Clear_map()"> Clear <br> Map Area</div><br> <br>
        </div>
     <footer class='container' style="position: fixed; bottom: 0px; width: 100%;">
         
    <div class="row">
        <hr>
         <div class="">
             <p style="padding-left: 2em;">© Copyright just cite me Jaime.</p>
        </div>
        <div>              
            <a><p style='padding-left: 2em; color:black;'><script>document.write(Date());</script></p></a>
            
        </div>
     </div> 
  </footer>    
</body>
</html>
